# 📱 Chat IA Pro - Android Nativo

## Projeto Android Nativo (SEM Node.js)

Este é um aplicativo Android puro desenvolvido em **Kotlin** que funciona com a API Syphnosys.

---

## ✅ APK Compilado, Alinhado e Assinado (v1+v2+v3)

O APK final (`dist/ChatIAPro-release.apk`) foi compilado e verificado com:

| Item | Valor |
|------|-------|
| `minSdkVersion` | 21 (Android 5.0) |
| `targetSdkVersion` | 34 (Android 14) |
| `compileSdkVersion` | 34 |
| Build-tools | 34.0.0 |
| JDK | 17 |
| Dex compiler | d8 |
| Assinatura | v1 (JAR) + v2 + v3 ✔ |
| `resources.arsc` | **STORED** (não comprimido) ✔ |
| zipalign | 4 bytes, verificado ✔ |
| Compatibilidade | Android 5.0 → 15+ (8, 9, 10, 11, 12, 13, 14, 15) |
| Tema | `Theme.Material3.DayNight.NoActionBar` (sem ActionBar) |

### 🔨 Compilar no Linux (reproduzível)

```bash
export ANDROID_HOME=/caminho/para/android-sdk   # precisa de platforms;android-34 e build-tools;34.0.0
export JAVA_HOME=/caminho/para/jdk-17
./build_apk.sh
```

### 🐞 Correções aplicadas nesta versão

- **Conexão com a API Syphnosys corrigida (permission denied resolvido)**: o app agora envia a requisição no formato correto (idêntico ao script de referência que funciona):
  - `Content-Type: application/x-www-form-urlencoded` (antes era `application/json`)
  - Autenticação no campo do corpo **`api_auth`** (antes ia no header `syph_auth`, que o servidor ignora)
  - Prompt no campo **`ai_prompt`** = histórico da conversa em JSON `[{"role","content"}]`
  - Campos extras **`app_version=77`** e header **`User-Agent: Dalvik/2.1.0`**
  - Resposta lida do formato OpenAI/Mistral: `choices[0].message.content`
  - Mantém histórico de conversa (system + user + assistant) para dar contexto.
  - Validado end-to-end: a API retorna respostas reais da IA.
- **Erro `Expected a JsonObject but was JsonPrimitive` corrigido**: a leitura da resposta agora é resiliente e aceita qualquer formato — string JSON pura (primitivo), objeto com campos comuns (`response`/`text`/`message`/`content`/`answer`/`output`/`reply`/`result`/`data`), formato estilo OpenAI (`choices[].message.content`), arrays, e até texto puro/HTML de erro. Validado com 12 testes automatizados.
- **NetworkOnMainThreadException corrigido**: a chamada HTTP (`OkHttp.execute()`) agora roda em `withContext(Dispatchers.IO)` em vez da thread principal.
- Adicionada dependência `kotlinx-coroutines-android` (necessária para `Dispatchers.Main`/`IO`).
- `Response` agora é fechado corretamente com `.use { }` (evita vazamento de conexões).
- `RequestBody` usa `MediaType` `application/json; charset=utf-8`.
- Removido `perplexityEndpoint` não utilizado.
- Removido o atributo `package` obsoleto do `AndroidManifest.xml` (o `namespace` do Gradle é usado no AGP 8).
- Adicionado `buildToolsVersion = "34.0.0"` explícito.
- Botão "Enviar" é desabilitado enquanto a requisição está em andamento.

---

### ✅ Funcionalidades

- 💬 Chat com IA (Syphnosys)
- 🔄 Histórico de mensagens
- 📱 Interface simples e intuitiva
- ⚡ Sem dependências de Node.js

### 🚀 Como Compilar

#### Pré-requisitos
- ✅ Android Studio (versão 2022.1+)
- ✅ Android SDK (API 26+)
- ✅ Gradle (incluído no Android Studio)
- ✅ Java 11+

#### Passo 1: Abrir no Android Studio

1. Abra o **Android Studio**
2. Selecione **File → Open**
3. Navegue até a pasta `ChatIAPro`
4. Clique em **OK**

#### Passo 2: Sincronizar Gradle

O Android Studio sincronizará automaticamente. Aguarde a conclusão.

#### Passo 3: Compilar o APK

**Opção A - Debug (para testes):**
1. Clique em **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Aguarde a compilação
3. APK estará em: `app/build/outputs/apk/debug/app-debug.apk`

**Opção B - Release (para distribuição):**
1. Clique em **Build → Generate Signed Bundle / APK**
2. Selecione **APK**
3. Crie uma chave de assinatura (ou use uma existente)
4. Clique em **Next** e **Finish**
5. APK estará em: `app/build/outputs/apk/release/app-release.apk`

#### Passo 4: Instalar no Dispositivo

**Via Android Studio:**
1. Conecte seu dispositivo Android
2. Clique em **Run → Run 'app'**
3. Selecione seu dispositivo
4. Clique em **OK**

**Via ADB (Linha de Comando):**
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### 📋 Estrutura do Projeto

```
ChatIAPro/
├── app/
│   ├── src/main/
│   │   ├── java/com/chatia/pro/
│   │   │   └── MainActivity.kt          # Activity principal
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   └── activity_main.xml    # Layout da tela
│   │   │   ├── values/
│   │   │   │   ├── strings.xml          # Strings
│   │   │   │   └── themes.xml           # Tema
│   │   │   └── drawable/
│   │   │       ├── edit_text_background.xml
│   │   │       └── button_background.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts                 # Configuração do app
├── build.gradle.kts                     # Configuração do projeto
├── settings.gradle                      # Configuração do Gradle
└── README.md
```

### 🔐 Credenciais

As credenciais já estão configuradas no código:

```kotlin
private val syphnosysEndpoint = "https://syphnosysapps.com/apis/release/..."
private val syphnosysAuthKey = "LIVE-V700-5T8T-8J6E-W5J6-J8R1-1D8Y-6K4A-..."
```

### 🎯 Uso do App

1. Digite uma mensagem no campo de texto
2. Clique em **Enviar**
3. Aguarde a resposta da IA
4. Continue a conversa

### 🔧 Troubleshooting

| Problema | Solução |
|----------|---------|
| Gradle sync failed | Clique em **File → Sync Now** |
| Compilação lenta | Primeira compilação é normal (5-10 min) |
| APK não instala | Verifique se o dispositivo está conectado |
| Erro de conexão | Verifique sua conexão com a internet |

### 📝 Notas

- **Sem Node.js**: Este projeto é 100% Android nativo
- **Sem Expo**: Usa apenas Android SDK e Gradle
- **Kotlin**: Linguagem moderna e segura
- **Mínimo Android 8.0** (API 26+)

### 🚀 Próximos Passos

1. Abra em Android Studio
2. Sincronize o Gradle
3. Compile o APK
4. Instale no seu dispositivo
5. Teste a aplicação

---

**Versão:** 1.0.0  
**Desenvolvido em:** Kotlin + Android SDK  
**Sem dependências de Node.js!** ✨
