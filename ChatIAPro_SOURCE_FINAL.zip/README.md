# 📱 PHCHAT - Android Nativo

## Projeto Android Nativo (SEM Node.js)

Aplicativo Android puro em **Kotlin** que funciona com a API Syphnosys.

**PHCHAT 7.0 FINAL (2027)** — Desenvolvido por **PAULO HERMINIO — (85) 98123-7727**.

### 🔐 Versão 3.0.0 — Login e MySQL (credenciais embutidas)

- **Login obrigatório no primeiro acesso** (tela de entrada/cadastro). A sessão fica lembrada nos próximos acessos; há opção **Sair (logout)** em ⚙.
- **Credenciais e tarefas salvas em MySQL** (`mysql.50webs.com` / `phchat_1`), com as credenciais **já embutidas no APK** — o usuário não precisa configurar nada. Senhas são gravadas com hash SHA-256.
- **Todas as tarefas ficam vinculadas ao usuário logado** (coluna `user_id`). Tabelas criadas automaticamente: `ph_users`, `ph_tasks`, `ph_messages`.
- **FTP também embutido** (usuário `stored` / senha `stored`, host `ftps2.50webs.com`) — sem necessidade de configurar.
- Testado ponta a ponta contra o banco real: cadastro, login, criação de tarefa, gravação/leitura de mensagens e listagem por usuário.
- Observação: o recurso de login/MySQL requer conexão de rede; recomendado Android 7+ para o driver MySQL.

### 🏷️ Identidade PHCHAT
- Nome do app, ícone (letras "PH" em degradê azul) e tema totalmente personalizados como **PHCHAT**.
- A IA se apresenta como PHCHAT e conhece o desenvolvedor (incluído no prompt de sistema).
- Ao perguntar **"quem é você"** (e variações), a resposta é garantida (tratada localmente): *"EU SOU PHCHAT 7.0 FINAL (2027) DESENVOLVIDO POR PAULO HERMINIO (85) 98123-7727"*.
- Em ⚙ → **Sobre o PHCHAT** aparecem os dados do desenvolvedor.

---

## ✅ APK Compilado, Alinhado e Assinado (v1+v2+v3)

O APK final (`dist/ChatIAPro-release.apk`) foi compilado e verificado com:

| Item | Valor |
|------|-------|
| `minSdkVersion` | 21 (Android 5.0) |
| `targetSdkVersion` | 34 (Android 14) |
| `compileSdkVersion` | 34 |
| Build-tools | 34.0.0 |
| JDK | 17 |
| Dex compiler | d8 |
| Assinatura | v1 (JAR) + v2 + v3 ✔ |
| `resources.arsc` | **STORED** (não comprimido) ✔ |
| zipalign | 4 bytes, verificado ✔ |
| Compatibilidade | Android 5.0 → 15+ (8, 9, 10, 11, 12, 13, 14, 15) |
| Tema | `Theme.Material3.DayNight.NoActionBar` (sem ActionBar) |

### 🔨 Compilar no Linux (reproduzível)

```bash
export ANDROID_HOME=/caminho/para/android-sdk   # precisa de platforms;android-34 e build-tools;34.0.0
export JAVA_HOME=/caminho/para/jdk-17
./build_apk.sh
```

### 📥 Baixar arquivos gerados pela IA

- Peça à IA para criar/gerar um arquivo (ex.: "crie um arquivo `app.py` que..."). A IA responde no formato `[SAVE: nome | conteúdo]` (definido no prompt de sistema).
- O app detecta os arquivos automaticamente e abre o seletor para **salvar no dispositivo** (Downloads ou onde você escolher), via Storage Access Framework — sem permissões extras.
- Suporta **múltiplos arquivos** por resposta e conteúdo com `]` (ex.: JSON/listas). Fallback: também detecta blocos de código ``` quando não há tag `[SAVE:]`.
- Para baixar de novo depois, **toque na mensagem da IA** que contém o arquivo. Tocar em mensagens sem arquivo oferece "Copiar texto".

### 🆕 Versão 2.0.0 — Tarefas, anexos ilimitados, FTP e cores

- **Abas de tarefas (Não finalizadas / Finalizadas):** cada conversa é uma tarefa persistida em SQLite. É possível abrir, ver, continuar (adicionar mensagens), renomear, excluir, **finalizar** e **reabrir** qualquer tarefa. As finalizadas ficam na aba própria para consulta/edição posterior.
- **Anexos ilimitados (qualquer tipo/tamanho):** removidos os limites de tamanho e as restrições de extensão. Arquivos de **texto/código** têm o conteúdo injetado no prompt (sem limite). Arquivos **binários** são enviados via **FTP** (se configurado) e o link é incluído na conversa.
- **Integração FTP configurável:** em ⚙ → *Configurar FTP* (host/usuário/senha/base URL). Host e base URL já vêm pré-preenchidos com os do script `.py` (o usuário/senha, que estavam ocultos como "stored", precisam ser informados). Também há ⚙ → *Exportar tarefa atual para FTP* (envia o histórico como `.txt`).
- **Seleção de cores:** ⚙ → *Cor das minhas mensagens* e *Cor das mensagens da IA* (paleta de cores + entrada HEX). As cores são persistidas e aplicadas ao chat.
- Persistência local completa (SQLite): tarefas, mensagens e configurações.

### 📎 Anexar arquivos ao chat

- Botão 📎 ao lado do campo de mensagem abre o seletor de arquivos (Storage Access Framework — não requer permissões no manifest).
- Permite anexar múltiplos arquivos de uma vez.
- **Arquivos de texto/código** (txt, py, md, json, html, css, js, ts, sql, kt, java, xml, csv, etc.): o conteúdo é lido e **injetado no prompt** enviado à IA (mesmo comportamento do script `.py`), com limite de ~200 KB por arquivo.
- **Imagens** (png, jpg, jpeg, webp, gif, bmp): anotadas pelo nome (o modelo Mistral é textual).
- Um indicador mostra os arquivos anexados antes do envio; são incorporados à próxima mensagem e depois limpos.
- Validado end-to-end: a IA lê e responde com base no conteúdo dos arquivos anexados.

### 🐞 Correções aplicadas nesta versão

- **Conexão com a API Syphnosys corrigida (permission denied resolvido)**: o app agora envia a requisição no formato correto (idêntico ao script de referência que funciona):
  - `Content-Type: application/x-www-form-urlencoded` (antes era `application/json`)
  - Autenticação no campo do corpo **`api_auth`** (antes ia no header `syph_auth`, que o servidor ignora)
  - Prompt no campo **`ai_prompt`** = histórico da conversa em JSON `[{"role","content"}]`
  - Campos extras **`app_version=77`** e header **`User-Agent: Dalvik/2.1.0`**
  - Resposta lida do formato OpenAI/Mistral: `choices[0].message.content`
  - Mantém histórico de conversa (system + user + assistant) para dar contexto.
  - Validado end-to-end: a API retorna respostas reais da IA.
- **Erro `Expected a JsonObject but was JsonPrimitive` corrigido**: a leitura da resposta agora é resiliente e aceita qualquer formato — string JSON pura (primitivo), objeto com campos comuns (`response`/`text`/`message`/`content`/`answer`/`output`/`reply`/`result`/`data`), formato estilo OpenAI (`choices[].message.content`), arrays, e até texto puro/HTML de erro. Validado com 12 testes automatizados.
- **NetworkOnMainThreadException corrigido**: a chamada HTTP (`OkHttp.execute()`) agora roda em `withContext(Dispatchers.IO)` em vez da thread principal.
- Adicionada dependência `kotlinx-coroutines-android` (necessária para `Dispatchers.Main`/`IO`).
- `Response` agora é fechado corretamente com `.use { }` (evita vazamento de conexões).
- `RequestBody` usa `MediaType` `application/json; charset=utf-8`.
- Removido `perplexityEndpoint` não utilizado.
- Removido o atributo `package` obsoleto do `AndroidManifest.xml` (o `namespace` do Gradle é usado no AGP 8).
- Adicionado `buildToolsVersion = "34.0.0"` explícito.
- Botão "Enviar" é desabilitado enquanto a requisição está em andamento.

---

### ✅ Funcionalidades

- 💬 Chat com IA (Syphnosys)
- 🔄 Histórico de mensagens
- 📱 Interface simples e intuitiva
- ⚡ Sem dependências de Node.js

### 🚀 Como Compilar

#### Pré-requisitos
- ✅ Android Studio (versão 2022.1+)
- ✅ Android SDK (API 26+)
- ✅ Gradle (incluído no Android Studio)
- ✅ Java 11+

#### Passo 1: Abrir no Android Studio

1. Abra o **Android Studio**
2. Selecione **File → Open**
3. Navegue até a pasta `ChatIAPro`
4. Clique em **OK**

#### Passo 2: Sincronizar Gradle

O Android Studio sincronizará automaticamente. Aguarde a conclusão.

#### Passo 3: Compilar o APK

**Opção A - Debug (para testes):**
1. Clique em **Build → Build Bundle(s) / APK(s) → Build APK(s)**
2. Aguarde a compilação
3. APK estará em: `app/build/outputs/apk/debug/app-debug.apk`

**Opção B - Release (para distribuição):**
1. Clique em **Build → Generate Signed Bundle / APK**
2. Selecione **APK**
3. Crie uma chave de assinatura (ou use uma existente)
4. Clique em **Next** e **Finish**
5. APK estará em: `app/build/outputs/apk/release/app-release.apk`

#### Passo 4: Instalar no Dispositivo

**Via Android Studio:**
1. Conecte seu dispositivo Android
2. Clique em **Run → Run 'app'**
3. Selecione seu dispositivo
4. Clique em **OK**

**Via ADB (Linha de Comando):**
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### 📋 Estrutura do Projeto

```
ChatIAPro/
├── app/
│   ├── src/main/
│   │   ├── java/com/chatia/pro/
│   │   │   └── MainActivity.kt          # Activity principal
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   └── activity_main.xml    # Layout da tela
│   │   │   ├── values/
│   │   │   │   ├── strings.xml          # Strings
│   │   │   │   └── themes.xml           # Tema
│   │   │   └── drawable/
│   │   │       ├── edit_text_background.xml
│   │   │       └── button_background.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts                 # Configuração do app
├── build.gradle.kts                     # Configuração do projeto
├── settings.gradle                      # Configuração do Gradle
└── README.md
```

### 🔐 Credenciais

As credenciais já estão configuradas no código:

```kotlin
private val syphnosysEndpoint = "https://syphnosysapps.com/apis/release/..."
private val syphnosysAuthKey = "LIVE-V700-5T8T-8J6E-W5J6-J8R1-1D8Y-6K4A-..."
```

### 🎯 Uso do App

1. Digite uma mensagem no campo de texto
2. Clique em **Enviar**
3. Aguarde a resposta da IA
4. Continue a conversa

### 🔧 Troubleshooting

| Problema | Solução |
|----------|---------|
| Gradle sync failed | Clique em **File → Sync Now** |
| Compilação lenta | Primeira compilação é normal (5-10 min) |
| APK não instala | Verifique se o dispositivo está conectado |
| Erro de conexão | Verifique sua conexão com a internet |

### 📝 Notas

- **Sem Node.js**: Este projeto é 100% Android nativo
- **Sem Expo**: Usa apenas Android SDK e Gradle
- **Kotlin**: Linguagem moderna e segura
- **Mínimo Android 8.0** (API 26+)

### 🚀 Próximos Passos

1. Abra em Android Studio
2. Sincronize o Gradle
3. Compile o APK
4. Instale no seu dispositivo
5. Teste a aplicação

---

**Versão:** 1.0.0  
**Desenvolvido em:** Kotlin + Android SDK  
**Sem dependências de Node.js!** ✨
