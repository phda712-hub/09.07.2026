#!/usr/bin/env bash
#
# ChatIAPro - Build de APK Moderno (Android 5.0 -> Android 15+)
# Reproduz exatamente a compilacao, alinhamento e assinatura tripla (v1+v2+v3).
#
# Pre-requisitos:
#   - JDK 17
#   - Android SDK com: platforms;android-34  e  build-tools;34.0.0
#   - Variavel ANDROID_HOME apontando para o SDK
#
set -euo pipefail

# ---- Configuracao ----
BT="${ANDROID_HOME:?Defina ANDROID_HOME}/build-tools/34.0.0"
KEYSTORE="dist/chatiapro.keystore"
ALIAS="chatiapro"
STOREPASS="chatiapro123"
KEYPASS="chatiapro123"

APK_UNSIGNED="app/build/outputs/apk/release/app-release-unsigned.apk"
APK_ALIGNED="dist/app-release-aligned.apk"
APK_FINAL="dist/ChatIAPro-release.apk"

mkdir -p dist

echo "==> [1/5] Compilando (Gradle + JDK17 + d8)"
./gradlew clean assembleRelease --no-daemon

echo "==> [2/5] Criando keystore (se nao existir)"
if [ ! -f "$KEYSTORE" ]; then
  keytool -genkeypair -v \
    -keystore "$KEYSTORE" -alias "$ALIAS" \
    -keyalg RSA -keysize 2048 -validity 10950 \
    -storepass "$STOREPASS" -keypass "$KEYPASS" \
    -dname "CN=Chat IA Pro, OU=Mobile, O=ChatIAPro, L=Sao Paulo, ST=SP, C=BR"
fi

echo "==> [3/5] zipalign 4 bytes (resources.arsc STORED preservado)"
"$BT/zipalign" -f -v -p 4 "$APK_UNSIGNED" "$APK_ALIGNED" | tail -3

echo "==> [4/5] Assinatura tripla v1 + v2 + v3"
"$BT/apksigner" sign \
  --ks "$KEYSTORE" --ks-key-alias "$ALIAS" \
  --ks-pass "pass:$STOREPASS" --key-pass "pass:$KEYPASS" \
  --v1-signing-enabled true \
  --v2-signing-enabled true \
  --v3-signing-enabled true \
  --v4-signing-enabled false \
  --out "$APK_FINAL" "$APK_ALIGNED"

echo "==> [5/5] Verificacao final"
"$BT/apksigner" verify --verbose "$APK_FINAL" | grep -E "Verified using v[123] scheme"
"$BT/zipalign" -c -v 4 "$APK_FINAL" >/dev/null && echo "zipalign: OK (4 bytes)"
unzip -v "$APK_FINAL" | grep resources.arsc

echo ""
echo "APK pronto: $APK_FINAL"
