#!/usr/bin/env bash
#
# PHCHAT - Build dos DOIS APKs (chat + gerenciador), alinhados e assinados (v1+v2+v3).
#
# Pré-requisitos: JDK 17, Android SDK com platforms;android-34 e build-tools;34.0.0, ANDROID_HOME.
#
set -euo pipefail

BT="${ANDROID_HOME:?Defina ANDROID_HOME}/build-tools/34.0.0"
KEYSTORE="dist/chatiapro.keystore"
ALIAS="chatiapro"
STOREPASS="chatiapro123"
KEYPASS="chatiapro123"

mkdir -p dist

echo "==> [1/4] Compilando os dois módulos (Gradle + JDK17 + d8)"
./gradlew clean :app:assembleRelease :admin:assembleRelease --no-daemon

echo "==> [2/4] Criando keystore (se não existir)"
if [ ! -f "$KEYSTORE" ]; then
  keytool -genkeypair -v \
    -keystore "$KEYSTORE" -alias "$ALIAS" \
    -keyalg RSA -keysize 2048 -validity 10950 \
    -storepass "$STOREPASS" -keypass "$KEYPASS" \
    -dname "CN=Chat IA Pro, OU=Mobile, O=ChatIAPro, L=Sao Paulo, ST=SP, C=BR"
fi

sign_apk () {
  local UNSIGNED="$1"
  local FINAL="$2"
  local ALIGNED="dist/_aligned.apk"
  echo "   - zipalign: $FINAL"
  "$BT/zipalign" -f -p 4 "$UNSIGNED" "$ALIGNED"
  echo "   - assinando v1+v2+v3: $FINAL"
  "$BT/apksigner" sign \
    --ks "$KEYSTORE" --ks-key-alias "$ALIAS" \
    --ks-pass "pass:$STOREPASS" --key-pass "pass:$KEYPASS" \
    --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
    --v4-signing-enabled false \
    --out "$FINAL" "$ALIGNED"
  rm -f "$ALIGNED"
  "$BT/apksigner" verify --verbose "$FINAL" | grep -E "Verified using v[123] scheme"
  "$BT/zipalign" -c 4 "$FINAL" >/dev/null && echo "     zipalign OK (4 bytes)"
}

echo "==> [3/4] Assinando o PHCHAT (chat)"
sign_apk "app/build/outputs/apk/release/app-release-unsigned.apk" "dist/PHCHAT.apk"

echo "==> [4/4] Assinando o PHCHAT Gerenciador (admin)"
sign_apk "admin/build/outputs/apk/release/admin-release-unsigned.apk" "dist/PHCHAT-Gerenciador.apk"

echo ""
echo "APKs prontos:"
echo "  - dist/PHCHAT.apk"
echo "  - dist/PHCHAT-Gerenciador.apk"
