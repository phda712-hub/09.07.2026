@echo off
setlocal enabledelayedexpansion

echo ====================================================
echo   ChatIAPro - Build de APK Moderno (Android 15+)
echo ====================================================

echo Verificando configuracao do Android SDK...
if defined ANDROID_HOME (
    set "SDK_PATH=%ANDROID_HOME%"
) else if defined ANDROID_SDK_ROOT (
    set "SDK_PATH=%ANDROID_SDK_ROOT%"
) else (
    set "DEFAULT_SDK=%LOCALAPPDATA%\Android\Sdk"
    if exist "!DEFAULT_SDK!" (
        set "SDK_PATH=!DEFAULT_SDK!"
    ) else (
        echo ERRO: Android SDK nao encontrado.
        pause
        exit /b 1
    )
)

echo SDK encontrado em: !SDK_PATH!

REM Criar local.properties
set "SAFE_SDK_PATH=!SDK_PATH:\=/!"
(echo sdk.dir=!SAFE_SDK_PATH!)>local.properties

echo Iniciando compilacao (JDK 17)...
IF EXIST gradlew.bat (
    call gradlew.bat assembleRelease
) ELSE (
    echo ERRO: gradlew.bat nao encontrado.
    pause
    exit /b 1
)

IF %ERRORLEVEL% NEQ 0 (
    echo.
    echo ERRO NA COMPILACAO. Verifique os erros acima.
    pause
    exit /b 1
)

echo.
echo ====================================================
echo   COMPILACAO CONCLUIDA COM SUCESSO!
echo ====================================================
echo.
echo Local do APK: app\build\outputs\apk\release\app-release-unsigned.apk
echo.
echo IMPORTANTE PARA COMPATIBILIDADE (Android 11+):
echo 1. Use o 'zipalign' para alinhar o APK (4 bytes).
echo 2. Use o 'apksigner' para assinatura tripla (v1 + v2 + v3).
echo.
echo O Gradle ja foi configurado para:
echo - targetSdkVersion 34 (Android 14/15)
echo - resources.arsc STORED (Nao comprimido)
echo - JDK 17 / d8 compiler
echo.
pause
