# Sem regras específicas (minify desabilitado).
