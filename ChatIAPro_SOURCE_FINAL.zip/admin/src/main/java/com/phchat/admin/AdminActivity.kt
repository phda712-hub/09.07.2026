package com.phchat.admin

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * PHCHAT Gerenciador — define o vencimento (licença) de cada usuário.
 * Sincroniza automaticamente com o app PHCHAT pelo mesmo banco MySQL.
 */
class AdminActivity : AppCompatActivity() {

    // Senha do administrador (embutida). Altere aqui se desejar.
    private val adminPassword = "phchat-admin-2027"

    private lateinit var listUsers: ListView
    private lateinit var buttonRefresh: Button
    private lateinit var textInfo: TextView
    private val users = mutableListOf<AdminMySql.UserRow>()
    private lateinit var adapter: UserAdapter
    private val dfDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)
        listUsers = findViewById(R.id.listUsers)
        buttonRefresh = findViewById(R.id.buttonRefresh)
        textInfo = findViewById(R.id.textInfo)

        adapter = UserAdapter()
        listUsers.adapter = adapter
        listUsers.setOnItemClickListener { _, _, position, _ -> showSetExpiryOptions(users[position]) }
        buttonRefresh.setOnClickListener { loadUsers() }

        promptAdminPassword()
    }

    private fun promptAdminPassword() {
        val input = EditText(this).apply {
            hint = "Senha do administrador"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setCancelable(false)
            .setTitle("PHCHAT Gerenciador")
            .setMessage("Digite a senha de administrador para continuar.")
            .setView(input)
            .setPositiveButton("Entrar") { _, _ ->
                if (input.text.toString() == adminPassword) {
                    loadUsers()
                } else {
                    Toast.makeText(this, "Senha incorreta.", Toast.LENGTH_LONG).show()
                    finish()
                }
            }
            .setNegativeButton("Sair") { _, _ -> finish() }
            .show()
    }

    private fun loadUsers() {
        textInfo.text = "Carregando usuários..."
        lifecycleScope.launch {
            try {
                val list = withContext(Dispatchers.IO) { AdminMySql.listUsers() }
                users.clear(); users.addAll(list); adapter.notifyDataSetChanged()
                textInfo.text = "${list.size} usuário(s). Toque em um para definir o vencimento."
            } catch (e: Exception) {
                textInfo.text = "Erro ao conectar: ${e.message}"
            }
        }
    }

    private fun showSetExpiryOptions(user: AdminMySql.UserRow) {
        val options = arrayOf(
            "+7 dias", "+15 dias", "+30 dias", "+90 dias",
            "Definir data (dd/mm/aaaa)...", "Definir nº de dias...", "Bloquear agora (expirar)"
        )
        AlertDialog.Builder(this)
            .setTitle("Usuário: ${user.username}")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> extendDays(user, 7)
                    1 -> extendDays(user, 15)
                    2 -> extendDays(user, 30)
                    3 -> extendDays(user, 90)
                    4 -> promptDate(user)
                    5 -> promptDays(user)
                    6 -> setExpiry(user, System.currentTimeMillis() - 1000)
                }
            }
            .show()
    }

    /** Adiciona N dias a partir de hoje OU do vencimento atual (o que for maior). */
    private fun extendDays(user: AdminMySql.UserRow, days: Int) {
        val base = maxOf(System.currentTimeMillis(), user.expiresAt)
        setExpiry(user, base + days.toLong() * 24 * 60 * 60 * 1000)
    }

    private fun promptDays(user: AdminMySql.UserRow) {
        val input = EditText(this).apply {
            hint = "Número de dias a partir de hoje"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        AlertDialog.Builder(this)
            .setTitle("Liberar por N dias")
            .setView(input)
            .setPositiveButton("Salvar") { _, _ ->
                val n = input.text.toString().toLongOrNull()
                if (n == null || n <= 0) { toast("Número inválido"); return@setPositiveButton }
                setExpiry(user, System.currentTimeMillis() + n * 24 * 60 * 60 * 1000)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun promptDate(user: AdminMySql.UserRow) {
        val input = EditText(this).apply {
            hint = "dd/mm/aaaa"
            inputType = InputType.TYPE_CLASS_DATETIME
        }
        AlertDialog.Builder(this)
            .setTitle("Definir data de vencimento")
            .setView(input)
            .setPositiveButton("Salvar") { _, _ ->
                try {
                    val d = dfDate.parse(input.text.toString().trim())
                    if (d == null) { toast("Data inválida"); return@setPositiveButton }
                    // Fim do dia informado (23:59:59)
                    val cal = Calendar.getInstance().apply {
                        time = d
                        set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59)
                    }
                    setExpiry(user, cal.timeInMillis)
                } catch (e: Exception) {
                    toast("Data inválida. Use dd/mm/aaaa")
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun setExpiry(user: AdminMySql.UserRow, millis: Long) {
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) { AdminMySql.setExpiresAt(user.id, millis) }
                toast("Vencimento de ${user.username}: ${dfDate.format(Date(millis))}")
                loadUsers()
            } catch (e: Exception) {
                toast("Falha: ${e.message}")
            }
        }
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private inner class UserAdapter : ArrayAdapter<AdminMySql.UserRow>(
        this, android.R.layout.simple_list_item_2, android.R.id.text1, users
    ) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = super.getView(position, convertView, parent)
            val u = users[position]
            view.findViewById<TextView>(android.R.id.text1).apply {
                text = u.username
                textSize = 17f
            }
            val now = System.currentTimeMillis()
            val status = when {
                u.expiresAt <= 0 -> "sem vencimento definido"
                u.expiresAt < now -> "EXPIRADO em ${dfDate.format(Date(u.expiresAt))}"
                else -> "liberado até ${dfDate.format(Date(u.expiresAt))}"
            }
            view.findViewById<TextView>(android.R.id.text2).text = status
            return view
        }
    }
}
