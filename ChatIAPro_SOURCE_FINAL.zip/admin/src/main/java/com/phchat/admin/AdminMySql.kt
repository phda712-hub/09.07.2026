package com.phchat.admin

import java.sql.Connection
import java.sql.DriverManager

/**
 * Acesso MySQL do app Gerenciador (mesmas credenciais/base do PHCHAT — sincronização automática).
 * Todos os métodos são bloqueantes: chamar em Dispatchers.IO.
 */
object AdminMySql {

    private const val HOST = "mysql.50webs.com"
    private const val DB = "phchat_1"
    private const val USER = "phchat_1"
    private const val PASS = "phchat_1"
    private const val URL =
        "jdbc:mysql://$HOST/$DB?connectTimeout=15000&socketTimeout=25000&useSSL=false&characterEncoding=UTF-8&autoReconnect=true"

    data class UserRow(val id: Long, val username: String, val expiresAt: Long)

    private fun conn(): Connection {
        Class.forName("com.mysql.jdbc.Driver")
        return DriverManager.getConnection(URL, USER, PASS)
    }

    fun ensureSchema() {
        conn().use { c ->
            c.createStatement().use { st ->
                st.execute(
                    "CREATE TABLE IF NOT EXISTS ph_users (" +
                        "id INT PRIMARY KEY AUTO_INCREMENT, username VARCHAR(64) UNIQUE, " +
                        "password VARCHAR(128), created_at BIGINT, expires_at BIGINT DEFAULT 0)"
                )
                try {
                    st.execute("ALTER TABLE ph_users ADD COLUMN expires_at BIGINT DEFAULT 0")
                } catch (_: Exception) {
                }
            }
        }
    }

    fun listUsers(): List<UserRow> {
        ensureSchema()
        val result = mutableListOf<UserRow>()
        conn().use { c ->
            c.createStatement().use { st ->
                st.executeQuery("SELECT id, username, expires_at FROM ph_users ORDER BY username ASC").use { rs ->
                    while (rs.next()) {
                        result.add(UserRow(rs.getLong("id"), rs.getString("username") ?: "", rs.getLong("expires_at")))
                    }
                }
            }
        }
        return result
    }

    fun setExpiresAt(userId: Long, millis: Long) {
        conn().use { c ->
            c.prepareStatement("UPDATE ph_users SET expires_at=? WHERE id=?").use { ps ->
                ps.setLong(1, millis)
                ps.setLong(2, userId)
                ps.executeUpdate()
            }
        }
    }
}
