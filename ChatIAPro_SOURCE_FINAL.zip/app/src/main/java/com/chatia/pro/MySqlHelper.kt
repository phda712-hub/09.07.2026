package com.chatia.pro

import java.security.MessageDigest
import java.sql.Connection
import java.sql.DriverManager
import java.sql.Statement

/**
 * Acesso ao MySQL (credenciais embutidas no APP — sem necessidade de configuração do usuário).
 * Guarda usuários (login), tarefas e mensagens, tudo vinculado ao usuário logado.
 *
 * IMPORTANTE: todos os métodos são BLOQUEANTES (JDBC). Chame sempre em Dispatchers.IO.
 */
object MySqlHelper {

    // Credenciais MySQL embutidas
    private const val HOST = "mysql.50webs.com"
    private const val DB = "phchat_1"
    private const val USER = "phchat_1"
    private const val PASS = "phchat_1"
    private const val URL =
        "jdbc:mysql://$HOST/$DB?connectTimeout=15000&socketTimeout=25000&useSSL=false&characterEncoding=UTF-8&autoReconnect=true"

    private fun conn(): Connection {
        Class.forName("com.mysql.jdbc.Driver")
        return DriverManager.getConnection(URL, USER, PASS)
    }

    fun sha256(s: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(s.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    /** Cria as tabelas se ainda não existirem. */
    fun ensureSchema() {
        conn().use { c ->
            c.createStatement().use { st ->
                st.execute(
                    "CREATE TABLE IF NOT EXISTS ph_users (" +
                        "id INT PRIMARY KEY AUTO_INCREMENT, " +
                        "username VARCHAR(64) UNIQUE, " +
                        "password VARCHAR(128), " +
                        "created_at BIGINT)"
                )
                st.execute(
                    "CREATE TABLE IF NOT EXISTS ph_tasks (" +
                        "id INT PRIMARY KEY AUTO_INCREMENT, " +
                        "user_id INT, " +
                        "title VARCHAR(255), " +
                        "finished TINYINT DEFAULT 0, " +
                        "updated_at BIGINT)"
                )
                st.execute(
                    "CREATE TABLE IF NOT EXISTS ph_messages (" +
                        "id INT PRIMARY KEY AUTO_INCREMENT, " +
                        "task_id INT, " +
                        "role VARCHAR(16), " +
                        "content MEDIUMTEXT, " +
                        "ts BIGINT)"
                )
            }
        }
    }

    /** Testa a conexão (para telas de status). */
    fun testConnection(): Boolean = conn().use { true }

    // ---- Usuários ----

    /** Cria uma conta. Retorna o id do usuário. Lança exceção se o usuário já existir. */
    fun register(username: String, password: String): Long {
        ensureSchema()
        conn().use { c ->
            c.prepareStatement("SELECT id FROM ph_users WHERE username=?").use { ps ->
                ps.setString(1, username)
                ps.executeQuery().use { rs ->
                    if (rs.next()) throw IllegalStateException("Este nome de usuário já existe.")
                }
            }
            c.prepareStatement(
                "INSERT INTO ph_users (username, password, created_at) VALUES (?,?,?)",
                Statement.RETURN_GENERATED_KEYS
            ).use { ins ->
                ins.setString(1, username)
                ins.setString(2, sha256(password))
                ins.setLong(3, System.currentTimeMillis())
                ins.executeUpdate()
                ins.generatedKeys.use { keys ->
                    keys.next()
                    return keys.getLong(1)
                }
            }
        }
    }

    /**
     * Troca a senha de um usuário, exigindo o nome de usuário e a senha antiga corretos.
     * Retorna true se trocou; false se usuário/senha antiga não conferem.
     */
    fun changePassword(username: String, oldPassword: String, newPassword: String): Boolean {
        ensureSchema()
        conn().use { c ->
            c.prepareStatement("SELECT id FROM ph_users WHERE username=? AND password=?").use { ps ->
                ps.setString(1, username)
                ps.setString(2, sha256(oldPassword))
                ps.executeQuery().use { rs ->
                    if (!rs.next()) return false
                }
            }
            c.prepareStatement("UPDATE ph_users SET password=? WHERE username=?").use { up ->
                up.setString(1, sha256(newPassword))
                up.setString(2, username)
                up.executeUpdate()
            }
        }
        return true
    }

    /** Faz login. Retorna o id do usuário ou null se credenciais inválidas. */
    fun login(username: String, password: String): Long? {
        ensureSchema()
        conn().use { c ->
            c.prepareStatement("SELECT id FROM ph_users WHERE username=? AND password=?").use { ps ->
                ps.setString(1, username)
                ps.setString(2, sha256(password))
                ps.executeQuery().use { rs ->
                    return if (rs.next()) rs.getLong(1) else null
                }
            }
        }
    }

    // ---- Tarefas ----

    fun listTasks(userId: Long, finished: Boolean): List<Task> {
        val result = mutableListOf<Task>()
        conn().use { c ->
            c.prepareStatement(
                "SELECT id, title, finished, updated_at FROM ph_tasks WHERE user_id=? AND finished=? ORDER BY updated_at DESC"
            ).use { ps ->
                ps.setLong(1, userId)
                ps.setInt(2, if (finished) 1 else 0)
                ps.executeQuery().use { rs ->
                    while (rs.next()) {
                        result.add(
                            Task(
                                rs.getLong("id"),
                                rs.getString("title") ?: "",
                                rs.getInt("finished") == 1,
                                rs.getLong("updated_at")
                            )
                        )
                    }
                }
            }
        }
        return result
    }

    fun getTask(id: Long): Task? {
        conn().use { c ->
            c.prepareStatement("SELECT id, title, finished, updated_at FROM ph_tasks WHERE id=?").use { ps ->
                ps.setLong(1, id)
                ps.executeQuery().use { rs ->
                    if (rs.next()) return Task(
                        rs.getLong("id"),
                        rs.getString("title") ?: "",
                        rs.getInt("finished") == 1,
                        rs.getLong("updated_at")
                    )
                }
            }
        }
        return null
    }

    fun createTask(userId: Long, title: String): Long {
        conn().use { c ->
            c.prepareStatement(
                "INSERT INTO ph_tasks (user_id, title, finished, updated_at) VALUES (?,?,0,?)",
                Statement.RETURN_GENERATED_KEYS
            ).use { ps ->
                ps.setLong(1, userId)
                ps.setString(2, title)
                ps.setLong(3, System.currentTimeMillis())
                ps.executeUpdate()
                ps.generatedKeys.use { keys ->
                    keys.next()
                    return keys.getLong(1)
                }
            }
        }
    }

    fun renameTask(id: Long, title: String) = exec(
        "UPDATE ph_tasks SET title=?, updated_at=? WHERE id=?"
    ) { it.setString(1, title); it.setLong(2, System.currentTimeMillis()); it.setLong(3, id) }

    fun setFinished(id: Long, finished: Boolean) = exec(
        "UPDATE ph_tasks SET finished=?, updated_at=? WHERE id=?"
    ) { it.setInt(1, if (finished) 1 else 0); it.setLong(2, System.currentTimeMillis()); it.setLong(3, id) }

    fun touchTask(id: Long) = exec(
        "UPDATE ph_tasks SET updated_at=? WHERE id=?"
    ) { it.setLong(1, System.currentTimeMillis()); it.setLong(2, id) }

    fun deleteTask(id: Long) {
        conn().use { c ->
            c.prepareStatement("DELETE FROM ph_messages WHERE task_id=?").use { it.setLong(1, id); it.executeUpdate() }
            c.prepareStatement("DELETE FROM ph_tasks WHERE id=?").use { it.setLong(1, id); it.executeUpdate() }
        }
    }

    // ---- Mensagens ----

    fun addMessage(taskId: Long, role: String, content: String) {
        conn().use { c ->
            c.prepareStatement("INSERT INTO ph_messages (task_id, role, content, ts) VALUES (?,?,?,?)").use { ps ->
                ps.setLong(1, taskId)
                ps.setString(2, role)
                ps.setString(3, content)
                ps.setLong(4, System.currentTimeMillis())
                ps.executeUpdate()
            }
            c.prepareStatement("UPDATE ph_tasks SET updated_at=? WHERE id=?").use { ps ->
                ps.setLong(1, System.currentTimeMillis())
                ps.setLong(2, taskId)
                ps.executeUpdate()
            }
        }
    }

    fun getMessages(taskId: Long): List<ChatMessage> {
        val result = mutableListOf<ChatMessage>()
        conn().use { c ->
            c.prepareStatement("SELECT role, content FROM ph_messages WHERE task_id=? ORDER BY id ASC").use { ps ->
                ps.setLong(1, taskId)
                ps.executeQuery().use { rs ->
                    while (rs.next()) result.add(ChatMessage(rs.getString(1), rs.getString(2) ?: ""))
                }
            }
        }
        return result
    }

    private inline fun exec(sql: String, bind: (java.sql.PreparedStatement) -> Unit) {
        conn().use { c -> c.prepareStatement(sql).use { ps -> bind(ps); ps.executeUpdate() } }
    }
}
