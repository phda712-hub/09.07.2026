package com.chatia.pro

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Uma mensagem da conversa (papel = "user" ou "assistant"). */
data class ChatMessage(val role: String, val content: String)

/** Uma tarefa/conversa. */
data class Task(
    val id: Long,
    var title: String,
    var finished: Boolean,
    var updatedAt: Long
)

/**
 * Persistência local em SQLite: tarefas, mensagens e configurações (cores, FTP).
 */
class ChatDatabase(context: Context) :
    SQLiteOpenHelper(context, "chatiapro.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                finished INTEGER NOT NULL DEFAULT 0,
                updated_at INTEGER NOT NULL
            )"""
        )
        db.execSQL(
            """CREATE TABLE messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                ts INTEGER NOT NULL
            )"""
        )
        db.execSQL("CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Sem migrações por enquanto.
    }

    // ---- Tarefas ----

    fun createTask(title: String): Long {
        val values = ContentValues().apply {
            put("title", title)
            put("finished", 0)
            put("updated_at", System.currentTimeMillis())
        }
        return writableDatabase.insert("tasks", null, values)
    }

    fun renameTask(id: Long, title: String) {
        val values = ContentValues().apply {
            put("title", title)
            put("updated_at", System.currentTimeMillis())
        }
        writableDatabase.update("tasks", values, "id=?", arrayOf(id.toString()))
    }

    fun setFinished(id: Long, finished: Boolean) {
        val values = ContentValues().apply {
            put("finished", if (finished) 1 else 0)
            put("updated_at", System.currentTimeMillis())
        }
        writableDatabase.update("tasks", values, "id=?", arrayOf(id.toString()))
    }

    fun touchTask(id: Long) {
        val values = ContentValues().apply { put("updated_at", System.currentTimeMillis()) }
        writableDatabase.update("tasks", values, "id=?", arrayOf(id.toString()))
    }

    fun deleteTask(id: Long) {
        writableDatabase.delete("messages", "task_id=?", arrayOf(id.toString()))
        writableDatabase.delete("tasks", "id=?", arrayOf(id.toString()))
    }

    fun getTask(id: Long): Task? {
        readableDatabase.query(
            "tasks", null, "id=?", arrayOf(id.toString()), null, null, null
        ).use { c ->
            if (c.moveToFirst()) return taskFromCursor(c)
        }
        return null
    }

    fun listTasks(finished: Boolean): List<Task> {
        val result = mutableListOf<Task>()
        readableDatabase.query(
            "tasks", null, "finished=?",
            arrayOf(if (finished) "1" else "0"),
            null, null, "updated_at DESC"
        ).use { c ->
            while (c.moveToNext()) result.add(taskFromCursor(c))
        }
        return result
    }

    private fun taskFromCursor(c: android.database.Cursor): Task {
        return Task(
            id = c.getLong(c.getColumnIndexOrThrow("id")),
            title = c.getString(c.getColumnIndexOrThrow("title")),
            finished = c.getInt(c.getColumnIndexOrThrow("finished")) == 1,
            updatedAt = c.getLong(c.getColumnIndexOrThrow("updated_at"))
        )
    }

    // ---- Mensagens ----

    fun addMessage(taskId: Long, role: String, content: String) {
        val values = ContentValues().apply {
            put("task_id", taskId)
            put("role", role)
            put("content", content)
            put("ts", System.currentTimeMillis())
        }
        writableDatabase.insert("messages", null, values)
        touchTask(taskId)
    }

    fun getMessages(taskId: Long): List<ChatMessage> {
        val result = mutableListOf<ChatMessage>()
        readableDatabase.query(
            "messages", arrayOf("role", "content"),
            "task_id=?", arrayOf(taskId.toString()),
            null, null, "id ASC"
        ).use { c ->
            while (c.moveToNext()) {
                result.add(ChatMessage(c.getString(0), c.getString(1)))
            }
        }
        return result
    }

    // ---- Configurações ----

    fun getSetting(key: String, default: String): String {
        readableDatabase.query(
            "settings", arrayOf("value"), "key=?", arrayOf(key), null, null, null
        ).use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return default
    }

    fun setSetting(key: String, value: String) {
        val values = ContentValues().apply {
            put("key", key)
            put("value", value)
        }
        writableDatabase.insertWithOnConflict(
            "settings", null, values, SQLiteDatabase.CONFLICT_REPLACE
        )
    }
}
