package com.chatia.pro

import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import java.io.ByteArrayInputStream

/**
 * Envio de arquivos via FTP (mesmo conceito do script .py).
 * As credenciais são configuráveis pelo usuário e ficam salvas em `settings`.
 */
object FtpHelper {

    data class Config(
        val host: String,
        val user: String,
        val pass: String,
        val baseUrl: String
    ) {
        val isConfigured: Boolean
            get() = host.isNotBlank() && user.isNotBlank() && pass.isNotBlank()
    }

    /**
     * Faz upload de bytes para o host FTP e retorna a URL pública (baseUrl + nome).
     * Lança exceção em caso de falha (o chamador trata).
     */
    fun upload(cfg: Config, remoteName: String, bytes: ByteArray): String {
        val ftp = FTPClient()
        ftp.connectTimeout = 20000
        try {
            ftp.connect(cfg.host)
            if (!ftp.login(cfg.user, cfg.pass)) {
                throw IllegalStateException("Login FTP falhou (usuário/senha).")
            }
            ftp.enterLocalPassiveMode()
            ftp.setFileType(FTP.BINARY_FILE_TYPE)
            val safeName = remoteName.replace(Regex("[^A-Za-z0-9._-]"), "_")
            ByteArrayInputStream(bytes).use { input ->
                if (!ftp.storeFile(safeName, input)) {
                    throw IllegalStateException("Falha ao enviar o arquivo (storeFile).")
                }
            }
            ftp.logout()
            val base = if (cfg.baseUrl.endsWith("/")) cfg.baseUrl else cfg.baseUrl + "/"
            return base + safeName
        } finally {
            try {
                if (ftp.isConnected) ftp.disconnect()
            } catch (_: Exception) {
            }
        }
    }
}
