package com.chatia.pro

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import com.google.gson.JsonObject
import com.google.gson.JsonElement
import com.google.gson.JsonParser
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var editTextMessage: EditText
    private lateinit var buttonSend: Button
    private lateinit var listViewMessages: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val messages = mutableListOf<String>()

    private val client = OkHttpClient()
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    // Credenciais
    private val syphnosysEndpoint = "https://syphnosysapps.com/apis/release/syct-api-v2-seor-wonm-zzvs-woeo/json/new-mistral-wcmu-wrsw-vnzc-sarw-wmcv-nawe-cczr-ooon-aecm-zsne-wzrw-unru-cooo-uszo-owco-zsov"
    private val syphnosysAuthKey = "LIVE-V700-5T8T-8J6E-W5J6-J8R1-1D8Y-6K4A-R5H8-C6E0-6R4Z-7H5D-T8E9-U5S6-8T9E-6J4S"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextMessage = findViewById(R.id.editTextMessage)
        buttonSend = findViewById(R.id.buttonSend)
        listViewMessages = findViewById(R.id.listViewMessages)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, messages)
        listViewMessages.adapter = adapter

        buttonSend.setOnClickListener {
            val message = editTextMessage.text.toString().trim()
            if (message.isNotEmpty()) {
                sendMessage(message)
                editTextMessage.text.clear()
            } else {
                Toast.makeText(this, "Digite uma mensagem", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendMessage(message: String) {
        messages.add("Você: $message")
        adapter.notifyDataSetChanged()
        listViewMessages.setSelection(messages.size - 1)

        buttonSend.isEnabled = false
        lifecycleScope.launch {
            val response = try {
                callSyphnosysAPI(message)
            } catch (e: Exception) {
                "Erro: ${e.message}"
            }
            messages.add("IA: $response")
            adapter.notifyDataSetChanged()
            listViewMessages.setSelection(messages.size - 1)
            buttonSend.isEnabled = true
        }
    }

    private suspend fun callSyphnosysAPI(prompt: String): String = withContext(Dispatchers.IO) {
        try {
            val jsonBody = JsonObject().apply {
                addProperty("prompt", prompt)
                addProperty("max_tokens", 2048)
                addProperty("temperature", 0.7)
            }

            val request = Request.Builder()
                .url(syphnosysEndpoint)
                .post(jsonBody.toString().toRequestBody(jsonMediaType))
                .addHeader("Content-Type", "application/json")
                .addHeader("syph_auth", syphnosysAuthKey)
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string()?.trim().orEmpty()
                if (!response.isSuccessful) {
                    return@use "Erro ${response.code}: ${extractText(body).ifBlank { response.message }}"
                }
                if (body.isEmpty()) "Sem resposta" else extractText(body)
            }
        } catch (e: IOException) {
            "Erro de conexão: ${e.message}"
        }
    }

    /**
     * Extrai o texto da resposta de forma resiliente, aceitando qualquer formato:
     * - String JSON pura (primitivo)  -> "texto"
     * - Objeto JSON com campos comuns  -> {"response|text|message|content|answer|output|reply|result": "..."}
     * - Formato estilo OpenAI          -> {"choices":[{"message":{"content":"..."}}]} ou {"choices":[{"text":"..."}]}
     * - Array JSON                     -> primeiro elemento
     * - Texto puro (não-JSON)          -> devolve o próprio texto
     */
    private fun extractText(raw: String): String {
        if (raw.isBlank()) return "Sem resposta"

        // 1) Tenta interpretar o corpo inteiro como JSON.
        try {
            val parsed = JsonParser.parseString(raw)
            // Resposta de status/erro no formato {"message":"..."} (sem campo de conteúdo) -> mensagem amigável.
            if (parsed.isJsonObject) {
                val o = parsed.asJsonObject
                val contentKeys = listOf("response", "text", "content", "answer", "output", "reply", "result", "choices")
                val messageEl = o.get("message")
                if (messageEl != null && messageEl.isJsonPrimitive && contentKeys.none { o.has(it) }) {
                    return friendlyServerMessage(messageEl.asString)
                }
            }
            return extractFromElement(parsed)
        } catch (_: Exception) { /* segue para o tratamento de resposta não-JSON */ }

        // 2) Resposta não é JSON puro (ex.: página de erro HTML do servidor).
        //    Procura um objeto JSON embutido no meio do HTML (ex.: {"message":"permission denied"}).
        val embedded = Regex("\\{[^{}]*\"message\"[^{}]*\\}").find(raw)?.value
        if (embedded != null) {
            try {
                val msg = JsonParser.parseString(embedded).asJsonObject.get("message")?.asString
                if (!msg.isNullOrBlank()) return friendlyServerMessage(msg)
            } catch (_: Exception) { /* ignora */ }
        }

        // 3) Detecta erro de servidor (PHP/HTML) e mostra mensagem limpa.
        val plain = raw.replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim()
        if (plain.contains("PHP Error", true) || plain.contains("json_decode", true)) {
            return "Falha no servidor da API. Verifique a chave de autenticação (syph_auth), " +
                "os créditos e se o endpoint continua ativo."
        }

        return plain.ifBlank { "Sem resposta" }
    }

    /** Converte mensagens de erro conhecidas da API em texto amigável em português. */
    private fun friendlyServerMessage(msg: String): String {
        val m = msg.trim()
        return when {
            m.equals("permission denied", true) ->
                "Acesso negado pela API (permission denied). A chave de autenticação pode estar " +
                "inválida, expirada ou sem créditos. Verifique suas credenciais Syphnosys."
            m.contains("unauthor", true) || m.contains("invalid", true) || m.contains("revoked", true) ->
                "Autenticação recusada pela API: $m. Verifique a chave/assinatura."
            else -> m
        }
    }

    private fun extractFromElement(el: JsonElement?): String {
        if (el == null || el.isJsonNull) return "Sem resposta"

        if (el.isJsonPrimitive) return el.asString

        if (el.isJsonArray) {
            val arr = el.asJsonArray
            return if (arr.size() > 0) extractFromElement(arr[0]) else "Sem resposta"
        }

        if (el.isJsonObject) {
            val obj = el.asJsonObject

            // Formato estilo OpenAI: choices[0].message.content ou choices[0].text
            obj.getAsJsonArray("choices")?.let { choices ->
                if (choices.size() > 0 && choices[0].isJsonObject) {
                    val first = choices[0].asJsonObject
                    first.getAsJsonObject("message")?.get("content")?.let {
                        if (it.isJsonPrimitive) return it.asString
                    }
                    first.get("text")?.let { if (it.isJsonPrimitive) return it.asString }
                }
            }

            // Campos de texto mais comuns
            for (key in listOf("response", "text", "message", "content", "answer", "output", "reply", "result", "data")) {
                obj.get(key)?.let { value ->
                    when {
                        value.isJsonPrimitive -> return value.asString
                        value.isJsonObject || value.isJsonArray -> {
                            val nested = extractFromElement(value)
                            if (nested.isNotBlank() && nested != "Sem resposta") return nested
                        }
                        else -> {}
                    }
                }
            }
        }
        return "Sem resposta"
    }
}
