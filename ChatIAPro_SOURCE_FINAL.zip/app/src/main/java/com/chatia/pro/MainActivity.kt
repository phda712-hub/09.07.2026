package com.chatia.pro

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.FormBody
import okhttp3.Request
import com.google.gson.JsonObject
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonParser
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var editTextMessage: EditText
    private lateinit var buttonSend: Button
    private lateinit var buttonAttach: Button
    private lateinit var textAttachments: TextView
    private lateinit var listViewMessages: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val messages = mutableListOf<String>()

    // Anexos pendentes (a serem injetados na próxima mensagem), igual ao script .py
    private data class Attachment(val name: String, val type: String, val content: String)
    private val attachments = mutableListOf<Attachment>()
    private val textExtensions = setOf(
        "txt", "py", "md", "json", "html", "htm", "css", "js", "ts", "sql", "xml", "csv",
        "kt", "java", "c", "cpp", "h", "hpp", "yml", "yaml", "ini", "log", "sh", "bat",
        "properties", "gradle", "kts", "php", "rb", "go", "rs", "swift", "cfg", "conf"
    )
    private val imageExtensions = setOf("png", "jpg", "jpeg", "webp", "gif", "bmp")
    private val maxTextBytes = 200 * 1024 // limite de leitura por arquivo de texto (~200 KB)

    private val client = OkHttpClient()

    // Credenciais e parâmetros da API Syphnosys (mesmo formato do script que funciona)
    private val syphnosysEndpoint = "https://syphnosysapps.com/apis/release/syct-api-v2-seor-wonm-zzvs-woeo/json/new-mistral-wcmu-wrsw-vnzc-sarw-wmcv-nawe-cczr-ooon-aecm-zsne-wzrw-unru-cooo-uszo-owco-zsov"
    private val syphnosysAuthKey = "LIVE-V700-5T8T-8J6E-W5J6-J8R1-1D8Y-6K4A-R5H8-C6E0-6R4Z-7H5D-T8E9-U5S6-8T9E-6J4S"
    private val appVersion = "77"

    // Histórico da conversa (role/content), enviado como "ai_prompt".
    private val systemPrompt = "Você é um assistente inteligente. Responda sempre em Português (Brasil), de forma clara e útil."
    private val conversation = JsonArray().apply {
        add(JsonObject().apply {
            addProperty("role", "system")
            addProperty("content", systemPrompt)
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextMessage = findViewById(R.id.editTextMessage)
        buttonSend = findViewById(R.id.buttonSend)
        buttonAttach = findViewById(R.id.buttonAttach)
        textAttachments = findViewById(R.id.textAttachments)
        listViewMessages = findViewById(R.id.listViewMessages)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, messages)
        listViewMessages.adapter = adapter

        buttonAttach.setOnClickListener {
            pickFiles.launch(arrayOf("*/*"))
        }

        buttonSend.setOnClickListener {
            val message = editTextMessage.text.toString().trim()
            if (message.isEmpty() && attachments.isEmpty()) {
                Toast.makeText(this, "Digite uma mensagem ou anexe um arquivo", Toast.LENGTH_SHORT).show()
            } else {
                sendMessage(message)
                editTextMessage.text.clear()
            }
        }
    }

    // Seletor de múltiplos arquivos (Storage Access Framework — não requer permissão no manifest).
    private val pickFiles = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isEmpty()) return@registerForActivityResult
        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.IO) { uris.mapNotNull { readAttachment(it) } }
            attachments.addAll(loaded)
            updateAttachmentsLabel()
            Toast.makeText(
                this@MainActivity,
                "${loaded.size} arquivo(s) anexado(s)",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun readAttachment(uri: Uri): Attachment? {
        return try {
            val name = queryFileName(uri) ?: "arquivo"
            val ext = name.substringAfterLast('.', "").lowercase()
            if (imageExtensions.contains(ext)) {
                Attachment(name, "image", "")
            } else {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
                val truncated = bytes.size > maxTextBytes
                val slice = if (truncated) bytes.copyOf(maxTextBytes) else bytes
                val text = String(slice, Charsets.UTF_8)
                val suffix = if (truncated) "\n...[conteúdo truncado]" else ""
                Attachment(name, "text", text + suffix)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun queryFileName(uri: Uri): String? {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) return cursor.getString(idx)
        }
        return uri.lastPathSegment
    }

    private fun updateAttachmentsLabel() {
        if (attachments.isEmpty()) {
            textAttachments.visibility = View.GONE
        } else {
            textAttachments.visibility = View.VISIBLE
            textAttachments.text = "📎 ${attachments.size} arquivo(s): " +
                attachments.joinToString(", ") { it.name }
        }
    }

    /** Monta o bloco de injeção dos anexos, no mesmo estilo do script .py. */
    private fun buildAttachmentsInjection(items: List<Attachment>): String {
        if (items.isEmpty()) return ""
        val sb = StringBuilder("\n\n[ARQUIVOS ANEXADOS]\n")
        for (a in items) {
            if (a.type == "text") {
                sb.append("\nARQUIVO: ${a.name}\n${a.content}\n")
            } else {
                sb.append("\nIMAGEM: ${a.name} (anexada pelo usuário)\n")
            }
        }
        return sb.toString()
    }

    private fun sendMessage(message: String) {
        // Captura os anexos atuais e injeta o conteúdo no payload enviado à IA.
        val pending = attachments.toList()
        val injection = buildAttachmentsInjection(pending)
        val fullPayload = (message + injection).trim()

        val displayText = when {
            message.isNotEmpty() && pending.isNotEmpty() -> "$message  [📎 ${pending.size} arquivo(s)]"
            message.isEmpty() && pending.isNotEmpty() -> "[📎 ${pending.size} arquivo(s) anexado(s)]"
            else -> message
        }
        messages.add("Você: $displayText")
        adapter.notifyDataSetChanged()
        listViewMessages.setSelection(messages.size - 1)

        // Limpa os anexos pendentes (já foram incorporados a esta mensagem).
        attachments.clear()
        updateAttachmentsLabel()

        buttonSend.isEnabled = false
        buttonAttach.isEnabled = false
        lifecycleScope.launch {
            val response = try {
                callSyphnosysAPI(fullPayload)
            } catch (e: Exception) {
                "Erro: ${e.message}"
            }
            messages.add("IA: $response")
            adapter.notifyDataSetChanged()
            listViewMessages.setSelection(messages.size - 1)
            buttonSend.isEnabled = true
            buttonAttach.isEnabled = true
        }
    }

    private suspend fun callSyphnosysAPI(prompt: String): String = withContext(Dispatchers.IO) {
        try {
            // Adiciona a mensagem do usuário ao histórico enviado como "ai_prompt".
            conversation.add(JsonObject().apply {
                addProperty("role", "user")
                addProperty("content", prompt)
            })

            // Corpo form-urlencoded: api_auth + ai_prompt (histórico JSON) + app_version.
            val formBody = FormBody.Builder()
                .add("api_auth", syphnosysAuthKey)
                .add("ai_prompt", conversation.toString())
                .add("app_version", appVersion)
                .build()

            val request = Request.Builder()
                .url(syphnosysEndpoint)
                .post(formBody)
                .addHeader("User-Agent", "Dalvik/2.1.0")
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string()?.trim().orEmpty()
                if (!response.isSuccessful) {
                    return@use "Erro ${response.code}: ${extractText(body).ifBlank { response.message }}"
                }
                if (body.isEmpty()) return@use "Sem resposta"

                val answer = extractText(body)
                // Mantém o contexto: guarda a resposta do assistente no histórico.
                if (answer.isNotBlank() && answer != "Sem resposta") {
                    conversation.add(JsonObject().apply {
                        addProperty("role", "assistant")
                        addProperty("content", answer)
                    })
                }
                answer
            }
        } catch (e: IOException) {
            "Erro de conexão: ${e.message}"
        }
    }

    /**
     * Extrai o texto da resposta de forma resiliente, aceitando qualquer formato:
     * - String JSON pura (primitivo)  -> "texto"
     * - Objeto JSON com campos comuns  -> {"response|text|message|content|answer|output|reply|result": "..."}
     * - Formato estilo OpenAI          -> {"choices":[{"message":{"content":"..."}}]} ou {"choices":[{"text":"..."}]}
     * - Array JSON                     -> primeiro elemento
     * - Texto puro (não-JSON)          -> devolve o próprio texto
     */
    private fun extractText(raw: String): String {
        if (raw.isBlank()) return "Sem resposta"

        // 1) Tenta interpretar como JSON. Primeiro o corpo inteiro; se falhar,
        //    tenta o trecho a partir da primeira '{' (servidor às vezes emite avisos PHP antes do JSON).
        for (candidate in jsonCandidates(raw)) {
            try {
                val parsed = JsonParser.parseString(candidate)
                // Resposta de status/erro no formato {"message":"..."} (sem campo de conteúdo) -> mensagem amigável.
                if (parsed.isJsonObject) {
                    val o = parsed.asJsonObject
                    val contentKeys = listOf("response", "text", "content", "answer", "output", "reply", "result", "choices")
                    val messageEl = o.get("message")
                    if (messageEl != null && messageEl.isJsonPrimitive && contentKeys.none { o.has(it) }) {
                        return friendlyServerMessage(messageEl.asString)
                    }
                }
                val extracted = extractFromElement(parsed)
                if (extracted.isNotBlank() && extracted != "Sem resposta") return extracted
            } catch (_: Exception) { /* tenta o próximo candidato */ }
        }

        // 2) Resposta não é JSON puro (ex.: página de erro HTML do servidor).
        //    Procura um objeto JSON embutido no meio do HTML (ex.: {"message":"permission denied"}).
        val embedded = Regex("\\{[^{}]*\"message\"[^{}]*\\}").find(raw)?.value
        if (embedded != null) {
            try {
                val msg = JsonParser.parseString(embedded).asJsonObject.get("message")?.asString
                if (!msg.isNullOrBlank()) return friendlyServerMessage(msg)
            } catch (_: Exception) { /* ignora */ }
        }

        // 3) Detecta erro de servidor (PHP/HTML) e mostra mensagem limpa.
        val plain = raw.replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim()
        if (plain.contains("PHP Error", true) || plain.contains("json_decode", true)) {
            return "Falha no servidor da API. Verifique a chave de autenticação (syph_auth), " +
                "os créditos e se o endpoint continua ativo."
        }

        return plain.ifBlank { "Sem resposta" }
    }

    /** Gera candidatos a JSON: o corpo inteiro e o trecho da primeira '{' até a última '}'. */
    private fun jsonCandidates(raw: String): List<String> {
        val list = mutableListOf(raw)
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start >= 0 && end > start) {
            val sub = raw.substring(start, end + 1)
            if (sub != raw) list.add(sub)
        }
        return list
    }

    /** Converte mensagens de erro conhecidas da API em texto amigável em português. */
    private fun friendlyServerMessage(msg: String): String {
        val m = msg.trim()
        return when {
            m.equals("permission denied", true) ->
                "Acesso negado pela API (permission denied). A chave de autenticação pode estar " +
                "inválida, expirada ou sem créditos. Verifique suas credenciais Syphnosys."
            m.contains("unauthor", true) || m.contains("invalid", true) || m.contains("revoked", true) ->
                "Autenticação recusada pela API: $m. Verifique a chave/assinatura."
            else -> m
        }
    }

    private fun extractFromElement(el: JsonElement?): String {
        if (el == null || el.isJsonNull) return "Sem resposta"

        if (el.isJsonPrimitive) return el.asString

        if (el.isJsonArray) {
            val arr = el.asJsonArray
            return if (arr.size() > 0) extractFromElement(arr[0]) else "Sem resposta"
        }

        if (el.isJsonObject) {
            val obj = el.asJsonObject

            // Formato estilo OpenAI: choices[0].message.content ou choices[0].text
            obj.getAsJsonArray("choices")?.let { choices ->
                if (choices.size() > 0 && choices[0].isJsonObject) {
                    val first = choices[0].asJsonObject
                    first.getAsJsonObject("message")?.get("content")?.let {
                        if (it.isJsonPrimitive) return it.asString
                    }
                    first.get("text")?.let { if (it.isJsonPrimitive) return it.asString }
                }
            }

            // Campos de texto mais comuns
            for (key in listOf("response", "text", "message", "content", "answer", "output", "reply", "result", "data")) {
                obj.get(key)?.let { value ->
                    when {
                        value.isJsonPrimitive -> return value.asString
                        value.isJsonObject || value.isJsonArray -> {
                            val nested = extractFromElement(value)
                            if (nested.isNotBlank() && nested != "Sem resposta") return nested
                        }
                        else -> {}
                    }
                }
            }
        }
        return "Sem resposta"
    }
}
