package com.chatia.pro

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.tabs.TabLayout
import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    // Views
    private lateinit var textTitle: TextView
    private lateinit var buttonBack: Button
    private lateinit var buttonSettings: Button
    private lateinit var taskListScreen: LinearLayout
    private lateinit var chatScreen: LinearLayout
    private lateinit var tabs: TabLayout
    private lateinit var listTasks: ListView
    private lateinit var buttonNewTask: Button
    private lateinit var listViewMessages: ListView
    private lateinit var buttonToggleFinished: Button
    private lateinit var editTextMessage: EditText
    private lateinit var buttonSend: Button
    private lateinit var buttonAttach: Button
    private lateinit var textAttachments: TextView

    // Estado
    private lateinit var db: ChatDatabase
    private var userId: Long = -1
    private var username: String = ""
    private var currentTaskId: Long? = null
    private var showingFinished = false
    private val messages = mutableListOf<ChatMessage>()
    private lateinit var msgAdapter: MessageAdapter
    private val taskItems = mutableListOf<Task>()
    private lateinit var taskAdapter: TaskAdapter
    private val dateFmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

    // Cores das mensagens (persistidas)
    private var userColor = 0xFF007AFF.toInt()
    private var aiColor = 0xFF00A67E.toInt()

    // Modelos de IA (todos com prefixo PH). Lista base + o que a IA retornar.
    private data class AiModel(val display: String, val raw: String, val desc: String)
    private val curatedModels = listOf(
        AiModel("PH Rápido", "ministral-8b-latest", "Respostas rápidas e leves para o dia a dia."),
        AiModel("PH Avançado", "mistral-large-latest", "Raciocínio mais profundo para tarefas complexas e textos longos."),
        AiModel("PH Código", "codestral-latest", "Especialista em programação: gera, explica e corrige código."),
        AiModel("PH Criativo", "open-mixtral-8x22b", "Ideias, textos criativos, roteiros e brainstorming."),
        AiModel("PH Preciso", "mistral-small-latest", "Respostas objetivas e factuais, com baixa criatividade.")
    )
    private var currentModelRaw = ""
    private var currentModelDisplay = ""

    // Anexos pendentes
    private data class Attachment(val name: String, val type: String, val content: String)
    private val attachments = mutableListOf<Attachment>()

    private val client = OkHttpClient()

    // API Syphnosys (formato validado)
    private val syphnosysEndpoint = "https://syphnosysapps.com/apis/release/syct-api-v2-seor-wonm-zzvs-woeo/json/new-mistral-wcmu-wrsw-vnzc-sarw-wmcv-nawe-cczr-ooon-aecm-zsne-wzrw-unru-cooo-uszo-owco-zsov"
    private val syphnosysAuthKey = "LIVE-V700-5T8T-8J6E-W5J6-J8R1-1D8Y-6K4A-R5H8-C6E0-6R4Z-7H5D-T8E9-U5S6-8T9E-6J4S"
    private val appVersion = "77"
    private val developerInfo = "PAULO HERMINIO (85) 98123-7727"
    private val identityAnswer = "EU SOU PHCHAT 7.0 FINAL (2027) DESENVOLVIDO POR PAULO HERMINIO (85) 98123-7727"
    private val systemPrompt = "Seu nome é PHCHAT. Você é o PHCHAT 7.0 FINAL (2027), desenvolvido por $developerInfo. " +
        "Responda sempre em Português (Brasil), de forma clara e útil. " +
        "Se o usuário perguntar quem é você, responda EXATAMENTE: \"$identityAnswer\". " +
        "Quando o usuário pedir para criar, gerar ou salvar um arquivo, forneça o arquivo COMPLETO usando EXATAMENTE o formato: " +
        "[SAVE: nome_do_arquivo.ext | conteúdo completo do arquivo]. Use uma tag [SAVE:] separada para cada arquivo e coloque-as ao final da resposta."

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = ChatDatabase(this)

        // Exige login: se não houver sessão, volta para a tela de login.
        val sid = db.getSetting("session_user_id", "")
        if (sid.isBlank()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        userId = sid.toLongOrNull() ?: -1
        username = db.getSetting("session_username", "")

        loadColors()
        loadFtpDefaults()
        currentModelRaw = db.getSetting("ai_model_raw", curatedModels[0].raw)
        currentModelDisplay = db.getSetting("ai_model_display", curatedModels[0].display)

        textTitle = findViewById(R.id.textTitle)
        buttonBack = findViewById(R.id.buttonBack)
        buttonSettings = findViewById(R.id.buttonSettings)
        taskListScreen = findViewById(R.id.taskListScreen)
        chatScreen = findViewById(R.id.chatScreen)
        tabs = findViewById(R.id.tabs)
        listTasks = findViewById(R.id.listTasks)
        buttonNewTask = findViewById(R.id.buttonNewTask)
        listViewMessages = findViewById(R.id.listViewMessages)
        buttonToggleFinished = findViewById(R.id.buttonToggleFinished)
        editTextMessage = findViewById(R.id.editTextMessage)
        buttonSend = findViewById(R.id.buttonSend)
        buttonAttach = findViewById(R.id.buttonAttach)
        textAttachments = findViewById(R.id.textAttachments)

        msgAdapter = MessageAdapter()
        listViewMessages.adapter = msgAdapter

        taskAdapter = TaskAdapter()
        listTasks.adapter = taskAdapter

        tabs.addTab(tabs.newTab().setText("Não finalizadas"))
        tabs.addTab(tabs.newTab().setText("Finalizadas"))
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                showingFinished = tab.position == 1
                reloadTasks()
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        listViewMessages.setOnItemClickListener { _, _, position, _ ->
            val m = messages[position]
            val files = if (m.role == "assistant") extractGeneratedFiles(m.content) else emptyList()
            if (files.isNotEmpty()) showDownloadDialog(files) else showMessageOptions(m)
        }

        listTasks.setOnItemClickListener { _, _, position, _ ->
            openTask(taskItems[position].id)
        }
        listTasks.setOnItemLongClickListener { _, _, position, _ ->
            showTaskOptions(taskItems[position]); true
        }

        buttonNewTask.setOnClickListener { promptNewTask() }
        buttonBack.setOnClickListener { showTaskList() }
        buttonSettings.setOnClickListener { showSettings() }
        buttonToggleFinished.setOnClickListener { toggleCurrentFinished() }
        buttonAttach.setOnClickListener { pickFiles.launch(arrayOf("*/*")) }
        buttonSend.setOnClickListener {
            val message = editTextMessage.text.toString().trim()
            if (message.isEmpty() && attachments.isEmpty()) {
                toast("Digite uma mensagem ou anexe um arquivo")
            } else {
                sendMessage(message)
                editTextMessage.text.clear()
            }
        }

        showTaskList()
    }

    // =======================================================================
    // NAVEGAÇÃO ENTRE TELAS
    // =======================================================================

    private fun showTaskList() {
        currentTaskId = null
        chatScreen.visibility = View.GONE
        taskListScreen.visibility = View.VISIBLE
        buttonBack.visibility = View.GONE
        textTitle.text = "PHCHAT"
        reloadTasks()
    }

    private fun showChatScreen() {
        taskListScreen.visibility = View.GONE
        chatScreen.visibility = View.VISIBLE
        buttonBack.visibility = View.VISIBLE
    }

    /** Executa uma operação de banco (MySQL) fora da thread principal, com tratamento de erro. */
    private fun <T> dbAsync(onResult: (T) -> Unit = {}, work: () -> T) {
        lifecycleScope.launch {
            try {
                val r = withContext(Dispatchers.IO) { work() }
                onResult(r)
            } catch (e: Exception) {
                toast("Erro no servidor: ${e.message}")
            }
        }
    }

    private fun reloadTasks() {
        dbAsync<List<Task>>(onResult = { list ->
            taskItems.clear()
            taskItems.addAll(list)
            taskAdapter.notifyDataSetChanged()
        }) { MySqlHelper.listTasks(userId, showingFinished) }
    }

    // =======================================================================
    // TAREFAS
    // =======================================================================

    private fun promptNewTask() {
        val input = EditText(this).apply {
            hint = "Nome da tarefa"
            setText("Nova tarefa")
        }
        AlertDialog.Builder(this)
            .setTitle("Nova tarefa")
            .setView(input)
            .setPositiveButton("Criar") { _, _ ->
                val name = input.text.toString().trim().ifBlank { "Nova tarefa" }
                dbAsync<Long>(onResult = { id -> openTask(id) }) { MySqlHelper.createTask(userId, name) }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showTaskOptions(task: Task) {
        val options = arrayOf(
            "Abrir",
            "Renomear",
            if (task.finished) "Reabrir (marcar não finalizada)" else "Marcar como finalizada",
            "Excluir"
        )
        AlertDialog.Builder(this)
            .setTitle(task.title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openTask(task.id)
                    1 -> promptRename(task)
                    2 -> dbAsync<Unit>(onResult = { reloadTasks() }) { MySqlHelper.setFinished(task.id, !task.finished) }
                    3 -> confirmDelete(task)
                }
            }
            .show()
    }

    private fun promptRename(task: Task) {
        val input = EditText(this).apply { setText(task.title) }
        AlertDialog.Builder(this)
            .setTitle("Renomear tarefa")
            .setView(input)
            .setPositiveButton("Salvar") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) dbAsync<Unit>(onResult = { reloadTasks() }) { MySqlHelper.renameTask(task.id, name) }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirmDelete(task: Task) {
        AlertDialog.Builder(this)
            .setTitle("Excluir tarefa")
            .setMessage("Excluir \"${task.title}\" e todo o histórico? Esta ação não pode ser desfeita.")
            .setPositiveButton("Excluir") { _, _ ->
                dbAsync<Unit>(onResult = { reloadTasks() }) { MySqlHelper.deleteTask(task.id) }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun openTask(taskId: Long) {
        dbAsync<Pair<Task?, List<ChatMessage>>>(onResult = { (task, msgs) ->
            if (task == null) {
                toast("Tarefa não encontrada")
            } else {
                currentTaskId = taskId
                textTitle.text = task.title
                buttonToggleFinished.text = if (task.finished) "↩ Reabrir tarefa" else "✔ Finalizar tarefa"
                messages.clear()
                messages.addAll(msgs)
                msgAdapter.notifyDataSetChanged()
                if (messages.isNotEmpty()) listViewMessages.setSelection(messages.size - 1)
                attachments.clear()
                updateAttachmentsLabel()
                showChatScreen()
            }
        }) {
            val t = MySqlHelper.getTask(taskId)
            val m = MySqlHelper.getMessages(taskId)
            Pair(t, m)
        }
    }

    private fun toggleCurrentFinished() {
        val id = currentTaskId ?: return
        dbAsync<Boolean>(onResult = { wasFinished ->
            toast(if (!wasFinished) "Tarefa finalizada" else "Tarefa reaberta")
            showTaskList()
        }) {
            val t = MySqlHelper.getTask(id) ?: throw IllegalStateException("Tarefa não encontrada")
            MySqlHelper.setFinished(id, !t.finished)
            t.finished
        }
    }

    // =======================================================================
    // ENVIO DE MENSAGENS
    // =======================================================================

    private fun sendMessage(message: String) {
        val taskId = currentTaskId ?: return
        val pending = attachments.toList()
        val injection = buildAttachmentsInjection(pending)
        val fullPayload = (message + injection).trim()

        // Auto-título a partir da primeira mensagem
        if (textTitle.text.toString().startsWith("Nova tarefa") && message.isNotEmpty()) {
            val newTitle = message.take(40)
            textTitle.text = newTitle
            dbAsync<Unit> { MySqlHelper.renameTask(taskId, newTitle) }
        }

        addMessage(ChatMessage("user", fullPayload))
        dbAsync<Unit> { MySqlHelper.addMessage(taskId, "user", fullPayload) }

        attachments.clear()
        updateAttachmentsLabel()

        buttonSend.isEnabled = false
        buttonAttach.isEnabled = false
        lifecycleScope.launch {
            // Resposta de identidade garantida (sem depender da IA) para "quem é você".
            val local = identityAnswerOrNull(message)
            val response = if (local != null) local else try {
                callSyphnosysAPI()
            } catch (e: Exception) {
                "Erro: ${e.message}"
            }
            addMessage(ChatMessage("assistant", response))
            dbAsync<Unit> { MySqlHelper.addMessage(taskId, "assistant", response) }
            buttonSend.isEnabled = true
            buttonAttach.isEnabled = true

            // Se a IA gerou arquivo(s), oferece o download imediatamente.
            val files = extractGeneratedFiles(response)
            if (files.isNotEmpty()) showDownloadDialog(files)
        }
    }

    private fun addMessage(m: ChatMessage) {
        messages.add(m)
        msgAdapter.notifyDataSetChanged()
        listViewMessages.setSelection(messages.size - 1)
    }

    /** Retorna a resposta de identidade fixa quando o usuário pergunta "quem é você" (e variações). */
    private fun identityAnswerOrNull(message: String): String? {
        val n = normalizeText(message)
        val direct = listOf(
            "quem e voce", "quem eh voce", "quem e vc", "quem eh vc",
            "quem es voce", "quem voce e", "quem vc e", "quem e voce afinal",
            "qual seu nome", "qual e seu nome", "qual o seu nome", "quem e vc afinal",
            "voce e quem", "vc e quem", "quem e tu", "quem es tu", "o que e voce", "o que voce e"
        )
        if (direct.any { n.contains(it) }) return identityAnswer
        if (Regex("\\bquem\\b.*\\b(voce|vc|tu)\\b").containsMatchIn(n)) return identityAnswer
        return null
    }

    /** Normaliza texto: minúsculas, sem acentos e sem pontuação. */
    private fun normalizeText(s: String): String {
        var t = s.lowercase().trim()
        t = t.replace(Regex("[áàâãä]"), "a").replace(Regex("[éèêë]"), "e")
            .replace(Regex("[íìîï]"), "i").replace(Regex("[óòôõö]"), "o")
            .replace(Regex("[úùûü]"), "u").replace("ç", "c")
        t = t.replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()
        return t
    }

    private suspend fun callSyphnosysAPI(): String = withContext(Dispatchers.IO) {
        try {
            // Monta o histórico (system + todas as mensagens) como "ai_prompt".
            val history = JsonArray()
            history.add(JsonObject().apply {
                addProperty("role", "system")
                addProperty("content", "$systemPrompt Modelo selecionado: $currentModelDisplay.")
            })
            for (m in messages) {
                history.add(JsonObject().apply {
                    addProperty("role", m.role)
                    addProperty("content", m.content)
                })
            }

            val formBody = FormBody.Builder()
                .add("api_auth", syphnosysAuthKey)
                .add("ai_prompt", history.toString())
                .add("app_version", appVersion)
                .add("ai_model", currentModelRaw)
                .build()

            val request = Request.Builder()
                .url(syphnosysEndpoint)
                .post(formBody)
                .addHeader("User-Agent", "Dalvik/2.1.0")
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string()?.trim().orEmpty()
                if (!response.isSuccessful) {
                    return@use "Erro ${response.code}: ${extractText(body).ifBlank { response.message }}"
                }
                if (body.isEmpty()) "Sem resposta" else extractText(body)
            }
        } catch (e: IOException) {
            "Erro de conexão: ${e.message}"
        }
    }

    // =======================================================================
    // ANEXOS (qualquer tipo / qualquer tamanho)
    // =======================================================================

    private val pickFiles = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isEmpty()) return@registerForActivityResult
        val ftp = currentFtpConfig()
        toast("Carregando ${uris.size} arquivo(s)...")
        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.IO) { uris.mapNotNull { readAttachment(it, ftp) } }
            attachments.addAll(loaded)
            updateAttachmentsLabel()
            toast("${loaded.size} arquivo(s) anexado(s)")
        }
    }

    // =======================================================================
    // DOWNLOAD DE ARQUIVOS GERADOS PELA IA
    // =======================================================================

    private data class GeneratedFile(val name: String, val content: String)

    private var pendingFileContent = ""

    // Cria/salva um arquivo no local escolhido pelo usuário (Downloads, etc.).
    private val createFile = registerForActivityResult(
        ActivityResultContracts.CreateDocument("*/*")
    ) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.openOutputStream(uri)?.use {
                it.write(pendingFileContent.toByteArray(Charsets.UTF_8))
            }
            toast("Arquivo salvo com sucesso")
        } catch (e: Exception) {
            toast("Falha ao salvar: ${e.message}")
        }
    }

    /**
     * Extrai arquivos da resposta da IA. Estratégia por segmentos (robusta a ']' no conteúdo
     * e a texto após o bloco): cada bloco vai de "[SAVE:" até o último ']' antes do próximo
     * "[SAVE:" ou do fim. Fallback: blocos de código cercados por ```.
     */
    private fun extractGeneratedFiles(text: String): List<GeneratedFile> {
        val files = mutableListOf<GeneratedFile>()
        val marker = "[SAVE:"
        var idx = text.indexOf(marker, ignoreCase = true)
        while (idx >= 0) {
            val afterMarker = idx + marker.length
            val nextIdx = text.indexOf(marker, afterMarker, ignoreCase = true)
            val segmentEnd = if (nextIdx >= 0) nextIdx else text.length
            val segment = text.substring(afterMarker, segmentEnd)
            val pipe = segment.indexOf('|')
            val closeRel = segment.lastIndexOf(']')
            if (pipe in 0 until closeRel) {
                val name = segment.substring(0, pipe).trim()
                val content = segment.substring(pipe + 1, closeRel).trim()
                addSaveFile(files, name, content)
            }
            idx = nextIdx
        }

        // Fallback: blocos de código cercados por ```.
        if (files.isEmpty()) {
            val code = Regex("```([a-zA-Z0-9]*)\\s*\\n([\\s\\S]*?)```")
            var i = 1
            for (mr in code.findAll(text)) {
                val content = mr.groupValues[2].trim()
                if (content.isNotEmpty()) {
                    files.add(GeneratedFile("arquivo_$i.${langToExt(mr.groupValues[1].trim().lowercase())}", content))
                    i++
                }
            }
        }
        return files
    }

    private fun addSaveFile(files: MutableList<GeneratedFile>, rawName: String, rawContent: String) {
        val name = rawName.trim()
        if (name.isEmpty()) return
        val content = rawContent.trim()
            .replace(Regex("^```[a-zA-Z0-9]*\\n?"), "")
            .replace(Regex("```$"), "")
            .trim()
        files.add(GeneratedFile(sanitizeFileName(name), content))
    }

    private fun sanitizeFileName(name: String): String =
        name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "arquivo.txt" }

    private fun langToExt(lang: String): String = when (lang) {
        "python", "py" -> "py"
        "kotlin", "kt" -> "kt"
        "java" -> "java"
        "javascript", "js" -> "js"
        "typescript", "ts" -> "ts"
        "html" -> "html"
        "css" -> "css"
        "json" -> "json"
        "xml" -> "xml"
        "sql" -> "sql"
        "bash", "sh", "shell" -> "sh"
        "c" -> "c"
        "cpp", "c++" -> "cpp"
        "php" -> "php"
        "md", "markdown" -> "md"
        else -> "txt"
    }

    private fun showDownloadDialog(files: List<GeneratedFile>) {
        if (files.isEmpty()) return
        if (files.size == 1) {
            startDownload(files[0]); return
        }
        val names = files.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Baixar arquivo gerado pela IA")
            .setItems(names) { _, which -> startDownload(files[which]) }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun startDownload(file: GeneratedFile) {
        pendingFileContent = file.content
        createFile.launch(file.name)
    }

    private fun showMessageOptions(m: ChatMessage) {
        AlertDialog.Builder(this)
            .setItems(arrayOf("Copiar texto")) { _, _ ->
                val clip = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clip.setPrimaryClip(android.content.ClipData.newPlainText("mensagem", m.content))
                toast("Copiado")
            }
            .show()
    }

    /** Lê o anexo. Texto: injeta o conteúdo (sem limite). Binário: envia por FTP (se configurado). */
    private fun readAttachment(uri: Uri, ftp: FtpHelper.Config): Attachment? {
        return try {
            val name = queryFileName(uri) ?: "arquivo_${System.currentTimeMillis()}"
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
            if (isProbablyText(bytes)) {
                Attachment(name, "text", String(bytes, Charsets.UTF_8))
            } else {
                // Binário: tenta enviar por FTP; senão, apenas anota.
                if (ftp.isConfigured) {
                    try {
                        val url = FtpHelper.upload(ftp, name, bytes)
                        Attachment(name, "binary", url)
                    } catch (e: Exception) {
                        Attachment(name, "binary", "FALHA_FTP: ${e.message}")
                    }
                } else {
                    Attachment(name, "binary", "")
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Heurística simples: sem bytes nulos nos primeiros 8 KB => provavelmente texto. */
    private fun isProbablyText(bytes: ByteArray): Boolean {
        val limit = minOf(bytes.size, 8192)
        for (i in 0 until limit) {
            if (bytes[i].toInt() == 0) return false
        }
        return true
    }

    private fun queryFileName(uri: Uri): String? {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) return cursor.getString(idx)
        }
        return uri.lastPathSegment
    }

    private fun updateAttachmentsLabel() {
        if (attachments.isEmpty()) {
            textAttachments.visibility = View.GONE
        } else {
            textAttachments.visibility = View.VISIBLE
            textAttachments.text = "📎 ${attachments.size} arquivo(s): " +
                attachments.joinToString(", ") { it.name }
        }
    }

    private fun buildAttachmentsInjection(items: List<Attachment>): String {
        if (items.isEmpty()) return ""
        val sb = StringBuilder("\n\n[ARQUIVOS ANEXADOS]\n")
        for (a in items) {
            when (a.type) {
                "text" -> sb.append("\nARQUIVO: ${a.name}\n${a.content}\n")
                "binary" -> {
                    if (a.content.startsWith("http")) {
                        sb.append("\nARQUIVO (binário): ${a.name} — disponível em: ${a.content}\n")
                    } else if (a.content.startsWith("FALHA_FTP")) {
                        sb.append("\nARQUIVO (binário): ${a.name} — não foi possível enviar por FTP (${a.content}).\n")
                    } else {
                        sb.append("\nARQUIVO (binário): ${a.name} — anexado (configure o FTP para enviar o conteúdo).\n")
                    }
                }
            }
        }
        return sb.toString()
    }

    // =======================================================================
    // CONFIGURAÇÕES (cores + FTP)
    // =======================================================================

    private fun showSettings() {
        val options = arrayOf(
            "Modelo de IA: $currentModelDisplay",
            "Cor das minhas mensagens",
            "Cor das mensagens da IA",
            "Exportar tarefa atual",
            "Sobre o PHCHAT",
            "Sair (logout: $username)"
        )
        AlertDialog.Builder(this)
            .setTitle("Configurações")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showModelSelector()
                    1 -> showColorPicker("Cor das minhas mensagens", userColor) {
                        userColor = it; db.setSetting("user_color", colorToHex(it)); msgAdapter.notifyDataSetChanged()
                    }
                    2 -> showColorPicker("Cor das mensagens da IA", aiColor) {
                        aiColor = it; db.setSetting("ai_color", colorToHex(it)); msgAdapter.notifyDataSetChanged()
                    }
                    3 -> exportCurrentTaskToFtp()
                    4 -> showAbout()
                    5 -> confirmLogout()
                }
            }
            .show()
    }

    // =======================================================================
    // SELETOR DE MODELOS (PHCHAT)
    // =======================================================================

    private fun showModelSelector() {
        toast("Consultando modelos da IA...")
        lifecycleScope.launch {
            val fetched = withContext(Dispatchers.IO) {
                try { fetchModelsFromApi() } catch (e: Exception) { emptyList() }
            }
            val all = (curatedModels + fetched).distinctBy { it.display }
            val items = all.map { "${it.display} — ${it.desc}" }.toTypedArray()
            val checked = all.indexOfFirst { it.raw == currentModelRaw }.let { if (it < 0) 0 else it }
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Escolha o modelo (PHCHAT)")
                .setSingleChoiceItems(items, checked) { d, which ->
                    val m = all[which]
                    currentModelRaw = m.raw
                    currentModelDisplay = m.display
                    db.setSetting("ai_model_raw", m.raw)
                    db.setSetting("ai_model_display", m.display)
                    toast("Modelo selecionado: ${m.display}")
                    d.dismiss()
                }
                .setNegativeButton("Fechar", null)
                .show()
        }
    }

    /** Pergunta à IA quais modelos estão disponíveis. Retorna lista (com prefixo PH). */
    private fun fetchModelsFromApi(): List<AiModel> {
        val history = JsonArray()
        history.add(JsonObject().apply {
            addProperty("role", "system")
            addProperty("content", "Você lista modelos de IA disponíveis nesta API.")
        })
        history.add(JsonObject().apply {
            addProperty("role", "user")
            addProperty(
                "content",
                "Liste os modelos de IA disponíveis que eu posso usar. Responda APENAS um JSON no formato " +
                    "{\"models\":[{\"nome\":\"...\",\"descricao\":\"...\"}]} sem texto extra."
            )
        })
        val formBody = FormBody.Builder()
            .add("api_auth", syphnosysAuthKey)
            .add("ai_prompt", history.toString())
            .add("app_version", appVersion)
            .build()
        val request = Request.Builder()
            .url(syphnosysEndpoint)
            .post(formBody)
            .addHeader("User-Agent", "Dalvik/2.1.0")
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string()?.trim().orEmpty()
            val content = extractText(body)
            val start = content.indexOf('{')
            val end = content.lastIndexOf('}')
            if (start < 0 || end <= start) return emptyList()
            val obj = JsonParser.parseString(content.substring(start, end + 1)).asJsonObject
            val arr = obj.getAsJsonArray("models") ?: return emptyList()
            val result = mutableListOf<AiModel>()
            for (el in arr) {
                if (!el.isJsonObject) continue
                val o = el.asJsonObject
                val nome = o.get("nome")?.asString?.trim().orEmpty()
                val desc = o.get("descricao")?.asString?.trim().orEmpty()
                if (nome.isNotEmpty()) {
                    result.add(AiModel("PH " + nome.removePrefix("PH ").trim(), nome, desc.ifBlank { "Modelo disponível na API." }))
                }
            }
            return result
        }
    }

    private fun confirmLogout() {
        AlertDialog.Builder(this)
            .setTitle("Sair")
            .setMessage("Deseja sair da conta \"$username\"? Suas tarefas continuam salvas no servidor.")
            .setPositiveButton("Sair") { _, _ ->
                db.setSetting("session_user_id", "")
                db.setSetting("session_username", "")
                startActivity(Intent(this, LoginActivity::class.java))
                finish()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("Sobre o PHCHAT")
            .setMessage(
                "PHCHAT 7.0 FINAL (2027)\n\n" +
                "Desenvolvido por:\nPAULO HERMINIO\n(85) 98123-7727"
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun loadColors() {
        userColor = parseColorOr(db.getSetting("user_color", "#007AFF"), 0xFF007AFF.toInt())
        aiColor = parseColorOr(db.getSetting("ai_color", "#00A67E"), 0xFF00A67E.toInt())
    }

    private fun parseColorOr(hex: String, fallback: Int): Int =
        try { Color.parseColor(hex) } catch (e: Exception) { fallback }

    private fun colorToHex(color: Int): String = String.format("#%06X", 0xFFFFFF and color)

    private fun showColorPicker(title: String, current: Int, onPick: (Int) -> Unit) {
        val palette = longArrayOf(
            0xFF007AFF, 0xFF34C759, 0xFFFF3B30, 0xFFFF9500, 0xFFFFCC00,
            0xFFAF52DE, 0xFF5856D6, 0xFF00C7BE, 0xFFFF2D55, 0xFF8E8E93,
            0xFF000000, 0xFF333333, 0xFF1E88E5, 0xFF43A047, 0xFFFFFFFF
        )
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 16)
        }
        val preview = TextView(this).apply {
            text = "  Prévia da cor selecionada  "
            setTextColor(current)
            textSize = 16f
            setPadding(0, 8, 0, 16)
        }
        root.addView(preview)

        val grid = GridLayout(this).apply { columnCount = 5 }
        val dialog = AlertDialog.Builder(this).setTitle(title).setView(root).create()
        for (c in palette) {
            val color = c.toInt()
            val swatch = View(this).apply {
                setBackgroundColor(color)
                val lp = GridLayout.LayoutParams().apply {
                    width = 110; height = 110; setMargins(10, 10, 10, 10)
                }
                layoutParams = lp
                setOnClickListener { onPick(color); dialog.dismiss() }
            }
            grid.addView(swatch)
        }
        root.addView(grid)

        val hexInput = EditText(this).apply {
            hint = "Ou digite um HEX, ex.: #FF8800"
            setText(colorToHex(current))
            inputType = InputType.TYPE_CLASS_TEXT
        }
        root.addView(hexInput)
        val applyHex = Button(this).apply {
            text = "Aplicar HEX"
            setOnClickListener {
                try {
                    val color = Color.parseColor(hexInput.text.toString().trim())
                    onPick(color); dialog.dismiss()
                } catch (e: Exception) {
                    toast("HEX inválido. Ex.: #FF8800")
                }
            }
        }
        root.addView(applyHex)
        dialog.show()
    }

    // ---- FTP ----

    private fun loadFtpDefaults() {
        // Credenciais FTP embutidas (não é necessário o usuário configurar).
        if (db.getSetting("ftp_host", "").isBlank()) db.setSetting("ftp_host", "ftps2.50webs.com")
        if (db.getSetting("ftp_user", "").isBlank()) db.setSetting("ftp_user", "stored")
        if (db.getSetting("ftp_pass", "").isBlank()) db.setSetting("ftp_pass", "stored")
        if (db.getSetting("ftp_base_url", "").isBlank()) db.setSetting("ftp_base_url", "http://stored.50webs.com/")
    }

    private fun currentFtpConfig(): FtpHelper.Config = FtpHelper.Config(
        host = db.getSetting("ftp_host", ""),
        user = db.getSetting("ftp_user", ""),
        pass = db.getSetting("ftp_pass", ""),
        baseUrl = db.getSetting("ftp_base_url", "")
    )

    private fun showFtpConfig() {
        val cfg = currentFtpConfig()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 8)
        }
        fun field(label: String, value: String, password: Boolean = false): EditText {
            root.addView(TextView(this).apply { text = label; setPadding(0, 12, 0, 0) })
            return EditText(this).apply {
                setText(value)
                inputType = if (password)
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                else InputType.TYPE_CLASS_TEXT
            }.also { root.addView(it) }
        }
        val hostF = field("Host FTP", cfg.host)
        val userF = field("Usuário", cfg.user)
        val passF = field("Senha", cfg.pass, password = true)
        val baseF = field("Base URL (http)", cfg.baseUrl)

        AlertDialog.Builder(this)
            .setTitle("Configurar FTP")
            .setView(root)
            .setPositiveButton("Salvar") { _, _ ->
                db.setSetting("ftp_host", hostF.text.toString().trim())
                db.setSetting("ftp_user", userF.text.toString().trim())
                db.setSetting("ftp_pass", passF.text.toString().trim())
                db.setSetting("ftp_base_url", baseF.text.toString().trim())
                toast("Configuração FTP salva")
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun exportCurrentTaskToFtp() {
        val id = currentTaskId
        if (id == null) { toast("Abra uma tarefa primeiro"); return }
        val cfg = currentFtpConfig()
        if (!cfg.isConfigured) { toast("Configure o FTP antes (usuário e senha)"); return }
        val fileName = "tarefa_${id}_${System.currentTimeMillis()}.txt"
        toast("Enviando para o FTP...")
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val task = MySqlHelper.getTask(id)
                    val sb = StringBuilder("# ${task?.title ?: "Tarefa"}\n\n")
                    for (m in MySqlHelper.getMessages(id)) {
                        sb.append(if (m.role == "user") "VOCÊ:\n" else "IA:\n")
                        sb.append(m.content).append("\n\n")
                    }
                    FtpHelper.upload(cfg, fileName, sb.toString().toByteArray(Charsets.UTF_8))
                } catch (e: Exception) { "ERRO: ${e.message}" }
            }
            if (result.startsWith("http")) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Tarefa exportada")
                    .setMessage("Disponível em:\n$result")
                    .setPositiveButton("OK", null)
                    .show()
            } else {
                toast("Falha ao exportar: $result")
            }
        }
    }

    // =======================================================================
    // ADAPTADORES
    // =======================================================================

    private inner class MessageAdapter : ArrayAdapter<ChatMessage>(
        this, android.R.layout.simple_list_item_1, messages
    ) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = super.getView(position, convertView, parent)
            val tv = view.findViewById<TextView>(android.R.id.text1)
            val m = messages[position]
            tv.text = displayContent(m)
            tv.setTextColor(if (m.role == "user") userColor else aiColor)
            return view
        }
    }

    private fun displayContent(m: ChatMessage): String {
        var c = m.content
        if (m.role == "user") {
            val marker = "\n\n[ARQUIVOS ANEXADOS]"
            val idx = c.indexOf(marker)
            if (idx >= 0) {
                val typed = c.substring(0, idx).trim()
                c = (if (typed.isEmpty()) "[arquivos anexados]" else typed) + "   [📎 anexos]"
            }
            return "Você: $c"
        }
        // IA: se há blocos [SAVE:], mostra o texto antes deles + a lista de arquivos gerados.
        val cut = c.indexOf("[SAVE:", ignoreCase = true)
        if (cut >= 0) {
            val files = extractGeneratedFiles(c)
            val before = c.substring(0, cut).trim()
            val names = files.joinToString(", ") { it.name }
            c = (before + "\n\n📄 Arquivo(s) gerado(s): " + names + "   (toque na mensagem para baixar)").trim()
        }
        return "IA: $c"
    }

    private inner class TaskAdapter : ArrayAdapter<Task>(
        this, android.R.layout.simple_list_item_2, android.R.id.text1, taskItems
    ) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view = super.getView(position, convertView, parent)
            val t = taskItems[position]
            view.findViewById<TextView>(android.R.id.text1).apply {
                text = t.title
                textSize = 17f
            }
            view.findViewById<TextView>(android.R.id.text2).text =
                "Atualizada: ${dateFmt.format(Date(t.updatedAt))}"
            return view
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    // =======================================================================
    // PARSING RESILIENTE DA RESPOSTA DA API
    // =======================================================================

    private fun extractText(raw: String): String {
        if (raw.isBlank()) return "Sem resposta"

        for (candidate in jsonCandidates(raw)) {
            try {
                val parsed = JsonParser.parseString(candidate)
                if (parsed.isJsonObject) {
                    val o = parsed.asJsonObject
                    val contentKeys = listOf("response", "text", "content", "answer", "output", "reply", "result", "choices")
                    val messageEl = o.get("message")
                    if (messageEl != null && messageEl.isJsonPrimitive && contentKeys.none { o.has(it) }) {
                        return friendlyServerMessage(messageEl.asString)
                    }
                }
                val extracted = extractFromElement(parsed)
                if (extracted.isNotBlank() && extracted != "Sem resposta") return extracted
            } catch (_: Exception) { /* próximo candidato */ }
        }

        val embedded = Regex("\\{[^{}]*\"message\"[^{}]*\\}").find(raw)?.value
        if (embedded != null) {
            try {
                val msg = JsonParser.parseString(embedded).asJsonObject.get("message")?.asString
                if (!msg.isNullOrBlank()) return friendlyServerMessage(msg)
            } catch (_: Exception) { }
        }

        val plain = raw.replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim()
        if (plain.contains("PHP Error", true) || plain.contains("json_decode", true)) {
            return "Falha no servidor da API. Verifique a chave de autenticação, os créditos e se o endpoint continua ativo."
        }
        return plain.ifBlank { "Sem resposta" }
    }

    private fun jsonCandidates(raw: String): List<String> {
        val list = mutableListOf(raw)
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start >= 0 && end > start) {
            val sub = raw.substring(start, end + 1)
            if (sub != raw) list.add(sub)
        }
        return list
    }

    private fun friendlyServerMessage(msg: String): String {
        val m = msg.trim()
        return when {
            m.equals("permission denied", true) ->
                "Acesso negado pela API (permission denied). A chave de autenticação pode estar inválida, expirada ou sem créditos."
            m.contains("unauthor", true) || m.contains("invalid", true) || m.contains("revoked", true) ->
                "Autenticação recusada pela API: $m."
            else -> m
        }
    }

    private fun extractFromElement(el: JsonElement?): String {
        if (el == null || el.isJsonNull) return "Sem resposta"
        if (el.isJsonPrimitive) return el.asString
        if (el.isJsonArray) {
            val arr = el.asJsonArray
            return if (arr.size() > 0) extractFromElement(arr[0]) else "Sem resposta"
        }
        if (el.isJsonObject) {
            val obj = el.asJsonObject
            obj.getAsJsonArray("choices")?.let { choices ->
                if (choices.size() > 0 && choices[0].isJsonObject) {
                    val first = choices[0].asJsonObject
                    first.getAsJsonObject("message")?.get("content")?.let {
                        if (it.isJsonPrimitive) return it.asString
                    }
                    first.get("text")?.let { if (it.isJsonPrimitive) return it.asString }
                }
            }
            for (key in listOf("response", "text", "message", "content", "answer", "output", "reply", "result", "data")) {
                obj.get(key)?.let { value ->
                    when {
                        value.isJsonPrimitive -> return value.asString
                        value.isJsonObject || value.isJsonArray -> {
                            val nested = extractFromElement(value)
                            if (nested.isNotBlank() && nested != "Sem resposta") return nested
                        }
                        else -> {}
                    }
                }
            }
        }
        return "Sem resposta"
    }

    override fun onBackPressed() {
        if (chatScreen.visibility == View.VISIBLE) {
            showTaskList()
        } else {
            super.onBackPressed()
        }
    }
}
