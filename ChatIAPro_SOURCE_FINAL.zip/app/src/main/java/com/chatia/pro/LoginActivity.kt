package com.chatia.pro

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Tela de login/cadastro. Exigida no primeiro acesso. As credenciais são gravadas no MySQL.
 * A sessão é lembrada localmente para os próximos acessos.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var db: ChatDatabase
    private lateinit var editUsername: EditText
    private lateinit var editPassword: EditText
    private lateinit var buttonLogin: Button
    private lateinit var buttonRegister: Button
    private lateinit var textStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = ChatDatabase(this)

        // Já logado? vai direto para o chat.
        if (db.getSetting("session_user_id", "").isNotBlank()) {
            goToMain()
            return
        }

        setContentView(R.layout.activity_login)
        editUsername = findViewById(R.id.editUsername)
        editPassword = findViewById(R.id.editPassword)
        buttonLogin = findViewById(R.id.buttonLogin)
        buttonRegister = findViewById(R.id.buttonRegister)
        textStatus = findViewById(R.id.textStatus)

        buttonLogin.setOnClickListener { doAuth(register = false) }
        buttonRegister.setOnClickListener { doAuth(register = true) }
    }

    private fun doAuth(register: Boolean) {
        val user = editUsername.text.toString().trim()
        val pass = editPassword.text.toString()
        if (user.isEmpty() || pass.isEmpty()) {
            textStatus.text = "Preencha usuário e senha."
            return
        }
        setBusy(true, if (register) "Criando conta..." else "Entrando...")
        lifecycleScope.launch {
            try {
                val userId = withContext(Dispatchers.IO) {
                    if (register) MySqlHelper.register(user, pass)
                    else MySqlHelper.login(user, pass)
                }
                if (userId == null || userId < 0) {
                    setBusy(false, "Usuário ou senha inválidos.")
                    return@launch
                }
                db.setSetting("session_user_id", userId.toString())
                db.setSetting("session_username", user)
                goToMain()
            } catch (e: Exception) {
                setBusy(false, "Falha: ${e.message}")
            }
        }
    }

    private fun setBusy(busy: Boolean, status: String) {
        buttonLogin.isEnabled = !busy
        buttonRegister.isEnabled = !busy
        textStatus.text = status
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
