package com.chatia.pro

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Tela de login/cadastro. Exigida no primeiro acesso. As credenciais são gravadas no MySQL.
 * A sessão é lembrada localmente para os próximos acessos.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var db: ChatDatabase
    private lateinit var editUsername: EditText
    private lateinit var editPassword: EditText
    private lateinit var buttonLogin: Button
    private lateinit var buttonRegister: Button
    private lateinit var buttonTogglePassword: Button
    private lateinit var buttonChangePassword: Button
    private lateinit var textStatus: TextView
    private var passwordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = ChatDatabase(this)

        // Já logado? vai direto para o chat.
        if (db.getSetting("session_user_id", "").isNotBlank()) {
            goToMain()
            return
        }

        setContentView(R.layout.activity_login)
        editUsername = findViewById(R.id.editUsername)
        editPassword = findViewById(R.id.editPassword)
        buttonLogin = findViewById(R.id.buttonLogin)
        buttonRegister = findViewById(R.id.buttonRegister)
        buttonTogglePassword = findViewById(R.id.buttonTogglePassword)
        buttonChangePassword = findViewById(R.id.buttonChangePassword)
        textStatus = findViewById(R.id.textStatus)

        buttonLogin.setOnClickListener { doAuth(register = false) }
        buttonRegister.setOnClickListener { doAuth(register = true) }
        buttonTogglePassword.setOnClickListener { togglePasswordVisibility() }
        buttonChangePassword.setOnClickListener { showChangePasswordDialog() }
    }

    /** Olho mágico: mostra/esconde a senha mantendo o cursor no fim. */
    private fun togglePasswordVisibility() {
        passwordVisible = !passwordVisible
        editPassword.transformationMethod = if (passwordVisible)
            HideReturnsTransformationMethod.getInstance()
        else
            PasswordTransformationMethod.getInstance()
        buttonTogglePassword.text = if (passwordVisible) "🙈" else "👁"
        editPassword.setSelection(editPassword.text.length)
    }

    /** Diálogo para trocar senha: exige usuário + senha antiga corretos. */
    private fun showChangePasswordDialog() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 8)
        }
        val userField = EditText(this).apply {
            hint = "Usuário"
            setText(editUsername.text.toString().trim())
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val oldField = EditText(this).apply {
            hint = "Senha atual"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val newField = EditText(this).apply {
            hint = "Nova senha"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val showChk = CheckBox(this).apply { text = "Mostrar senhas" }
        showChk.setOnCheckedChangeListener { _, checked ->
            val t = if (checked) HideReturnsTransformationMethod.getInstance()
                    else PasswordTransformationMethod.getInstance()
            oldField.transformationMethod = t
            newField.transformationMethod = t
            oldField.setSelection(oldField.text.length)
            newField.setSelection(newField.text.length)
        }
        root.addView(userField); root.addView(oldField); root.addView(newField); root.addView(showChk)

        AlertDialog.Builder(this)
            .setTitle("Trocar senha")
            .setView(root)
            .setPositiveButton("Trocar") { _, _ ->
                val u = userField.text.toString().trim()
                val old = oldField.text.toString()
                val nw = newField.text.toString()
                if (u.isEmpty() || old.isEmpty() || nw.isEmpty()) {
                    textStatus.text = "Preencha usuário, senha atual e nova senha."
                    return@setPositiveButton
                }
                if (nw.length < 3) {
                    textStatus.text = "A nova senha é muito curta."
                    return@setPositiveButton
                }
                textStatus.text = "Trocando senha..."
                lifecycleScope.launch {
                    try {
                        val ok = withContext(Dispatchers.IO) { MySqlHelper.changePassword(u, old, nw) }
                        textStatus.text = if (ok) "Senha trocada com sucesso! Faça login."
                            else "Usuário ou senha atual incorretos."
                    } catch (e: Exception) {
                        textStatus.text = "Falha: ${e.message}"
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun doAuth(register: Boolean) {
        val user = editUsername.text.toString().trim()
        val pass = editPassword.text.toString()
        if (user.isEmpty() || pass.isEmpty()) {
            textStatus.text = "Preencha usuário e senha."
            return
        }
        setBusy(true, if (register) "Criando conta..." else "Entrando...")
        lifecycleScope.launch {
            try {
                val userId = withContext(Dispatchers.IO) {
                    if (register) MySqlHelper.register(user, pass)
                    else MySqlHelper.login(user, pass)
                }
                if (userId == null || userId < 0) {
                    setBusy(false, "Usuário ou senha inválidos.")
                    return@launch
                }
                db.setSetting("session_user_id", userId.toString())
                db.setSetting("session_username", user)
                goToMain()
            } catch (e: Exception) {
                setBusy(false, "Falha: ${e.message}")
            }
        }
    }

    private fun setBusy(busy: Boolean, status: String) {
        buttonLogin.isEnabled = !busy
        buttonRegister.isEnabled = !busy
        textStatus.text = status
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
